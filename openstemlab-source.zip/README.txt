Open STEM Lab — source repository.
Run python3 build.py --production to generate the full static platform.
Original code and lesson text are MIT licensed.
