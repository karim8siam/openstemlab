Open STEM Lab — editable public website.
Serve this folder with python3 -m http.server 8000.
Original code and lesson text are MIT licensed; external fonts retain their own licenses.
