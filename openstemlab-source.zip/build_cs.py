"""Static lesson pages and reproducible simulated reports for published Computer Science labs."""
from pathlib import Path
import json,math,csv,io,sqlite3,html,re

ROOT=Path(__file__).resolve().parent
E=lambda s:html.escape(str(s),quote=True)
def specs():return json.loads((ROOT/'content/cs/experiments.json').read_text())
def rnd(x,n):return math.floor(x*10**n+.5)/10**n

def observation(c,value):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  n=float(value)
  x=math.log2(n)
  raw=int(math.floor(x)+1)
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='quadratic-sorting-algorithms':
  n=float(value)
  x=n*(n-1.0)
  raw=int(n*(n-1.0)/2.0)
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='divide-conquer-sorting':
  n=float(value)
  log2n=math.log2(n)
  x=n*(log2n - 1.0)
  raw=int(round(n*log2n - n + 1.0))
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='stack-adt-recursion':
  n=float(value)
  x=n
  raw=int(round(64.0*n + 128.0))
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='queue-buffer-management':
  n=float(value)
  x=n
  raw=int(round(64.0*n + 256.0))
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='linked-list-architectures':
  n=float(value)
  x=n
  raw=int(round(32.0*n + 64.0))
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='binary-search-trees':
  n=float(value)
  x=math.log2(n)
  raw=int(math.floor(x)+1)
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='binary-heaps-priority-queues':
  n=float(value)
  log2n=math.log2(n)
  raw=int(round(2.0*n - 2.0*log2n))
  x=n - log2n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='hash-tables-collision-resolution':
  n=float(value)
  m_cap=1000.0
  alpha=n/m_cap
  x=1.0/(1.0 - alpha)
  raw=rnd(x, 4)
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='graph-traversal-shortest-paths':
  v=float(value)
  e=4.0*v
  raw=int(round(v + e))
  x=v
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='dynamic-programming-memoization':
  n=float(value)
  w_cap=100.0
  raw=int(round(w_cap * n))
  x=n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='greedy-minimum-spanning-trees':
  v=float(value)
  e=4.0*v
  raw=int(round(2.0*e))
  x=v
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='string-matching-automata':
  n=float(value)
  m_pat=20.0
  raw=int(round(n + m_pat))
  x=n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='network-flow-max-cut':
  v=float(value)
  raw=int(round(10.0*v))
  x=v
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='trie-prefix-trees':
  l=float(value)
  raw=int(round(l + 1.0))
  x=l
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='huffman-coding-compression':
  n=float(value)
  raw=int(round(2.5 * n + 64.0))
  x=n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='computational-geometry-convex-hull':
  n=float(value)
  raw=int(round(2.0 * n))
  x=n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='backtracking-n-queens-sat':
  n=float(value)
  raw=int(round(4.0 * n))
  x=n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='b-tree-disk-indexing':
  h=float(value)
  raw=int(round(8.0 * h))
  x=h
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='fast-fourier-transform':
  n=float(value)
  log2n=round(math.log2(n))
  raw=int(round(0.5 * n * log2n))
  x=n * log2n
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='a-star-pathfinding-heuristics':
  d=float(value)
  raw=int(round(3.0 * d))
  x=d
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='lru-cache-replacement':
  c_val=float(value)
  raw=int(round(6.0 * c_val))
  x=c_val
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='cryptographic-rsa-modular':
  b_bits=float(value)
  raw=int(round(1.5 * b_bits))
  x=b_bits
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='concurrency-synchronization-deadlock':
  n_threads=float(value)
  raw=int(round(4.0 * n_threads))
  x=n_threads
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 elif slug=='relational-query-optimization':
  n_tuples=float(value)
  raw=int(round(2.0 * n_tuples))
  x=n_tuples
  y=float(raw)
  return {'input':value,'raw':raw,'x':x,'y':y}
 raise ValueError(f"Unknown CS experiment {slug}")

def fit(rows):
 n=len(rows)
 mx=sum(r['x'] for r in rows)/n
 my=sum(r['y'] for r in rows)/n
 sxx=sum((r['x']-mx)**2 for r in rows)
 sxy=sum((r['x']-mx)*(r['y']-my) for r in rows)
 m=sxy/sxx if sxx>0 else 1.0
 b=my-m*mx
 sse=sum((r['y']-m*r['x']-b)**2 for r in rows)
 syy=sum((r['y']-my)**2 for r in rows)
 variance=sse/(n-2) if n>2 and sse>0 else 1e-12
 return dict(
  m=m,b=b,sse=sse,
  slopeSE=math.sqrt(variance/sxx) if sxx>0 else 0.0,
  interceptSE=math.sqrt(variance*(1/n+mx*mx/sxx)) if sxx>0 else 0.0,
  mx=mx,my=my,sxx=sxx,sxy=sxy,
  r2=1.0-sse/syy if syy>0 else 1.0
 )

def estimate(c,f):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='quadratic-sorting-algorithms':
  return f['m'],f['slopeSE'],0.5000
 elif slug=='divide-conquer-sorting':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='stack-adt-recursion':
  return f['m'],f['slopeSE'],64.0000
 elif slug=='queue-buffer-management':
  return f['m'],f['slopeSE'],64.0000
 elif slug=='linked-list-architectures':
  return f['m'],f['slopeSE'],32.0000
 elif slug=='binary-search-trees':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='binary-heaps-priority-queues':
  return f['m'],f['slopeSE'],2.0000
 elif slug=='hash-tables-collision-resolution':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='graph-traversal-shortest-paths':
  return f['m'],f['slopeSE'],5.0000
 elif slug=='dynamic-programming-memoization':
  return f['m'],f['slopeSE'],100.0000
 elif slug=='greedy-minimum-spanning-trees':
  return f['m'],f['slopeSE'],8.0000
 elif slug=='string-matching-automata':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='network-flow-max-cut':
  return f['m'],f['slopeSE'],10.0000
 elif slug=='trie-prefix-trees':
  return f['m'],f['slopeSE'],1.0000
 elif slug=='huffman-coding-compression':
  return f['m'],f['slopeSE'],2.5000
 elif slug=='computational-geometry-convex-hull':
  return f['m'],f['slopeSE'],2.0000
 elif slug=='backtracking-n-queens-sat':
  return f['m'],f['slopeSE'],4.0000
 elif slug=='b-tree-disk-indexing':
  return f['m'],f['slopeSE'],8.0000
 elif slug=='fast-fourier-transform':
  return f['m'],f['slopeSE'],0.5000
 elif slug=='a-star-pathfinding-heuristics':
  return f['m'],f['slopeSE'],3.0000
 elif slug=='lru-cache-replacement':
  return f['m'],f['slopeSE'],6.0000
 elif slug=='cryptographic-rsa-modular':
  return f['m'],f['slopeSE'],1.5000
 elif slug=='concurrency-synchronization-deadlock':
  return f['m'],f['slopeSE'],4.0000
 elif slug=='relational-query-optimization':
  return f['m'],f['slopeSE'],2.0000
 raise ValueError(f"Unknown CS experiment {slug}")

def fmt(v,n=5):
 return f'{v:.4e}' if v and (abs(v)<.001 or abs(v)>=1e6) else f'{v:.{n}f}'

def formula(c,f):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  val=f['m']*c['resultScale']
  return f"k_search = m = {fmt(val,c['resultDecimals'])} comparisons/bit; Intercept b = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical intercept = 1.0000)"
 elif slug=='quadratic-sorting-algorithms':
  val=f['m']*c['resultScale']
  return f"a_quad = m = {fmt(val,c['resultDecimals'])} comparisons/pair; Intercept b = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical a = 0.5000, b = 0.0000)"
 elif slug=='divide-conquer-sorting':
  val=f['m']*c['resultScale']
  return f"k_merge = m = {fmt(val,c['resultDecimals'])} comparisons/interval; Intercept b = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical k = 1.0000, b = 1.0000)"
 elif slug=='stack-adt-recursion':
  val=f['m']*c['resultScale']
  return f"F_frame = m = {fmt(val,c['resultDecimals'])} bytes/frame; Intercept M_0 = {fmt(f['b'],c['resultDecimals'])} bytes (theoretical frame F = 64.0000, base M_0 = 128.0000)"
 elif slug=='queue-buffer-management':
  val=f['m']*c['resultScale']
  return f"L_packet = m = {fmt(val,c['resultDecimals'])} bytes/packet; Intercept V_0 = {fmt(f['b'],c['resultDecimals'])} bytes (theoretical payload L = 64.0000, descriptor header V_0 = 256.0000)"
 elif slug=='linked-list-architectures':
  val=f['m']*c['resultScale']
  return f"S_node = m = {fmt(val,c['resultDecimals'])} bytes/node; Intercept M_0 = {fmt(f['b'],c['resultDecimals'])} bytes (theoretical node size S = 32.0000, sentinels M_0 = 64.0000)"
 elif slug=='binary-search-trees':
  val=f['m']*c['resultScale']
  return f"alpha = m = {fmt(val,c['resultDecimals'])} levels/bit; Intercept h_0 = {fmt(f['b'],c['resultDecimals'])} levels (theoretical alpha = 1.0000, h_0 = 1.0000)"
 elif slug=='binary-heaps-priority-queues':
  val=f['m']*c['resultScale']
  return f"k_heap = m = {fmt(val,c['resultDecimals'])} comparisons/interval; Intercept C_0 = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical k_heap = 2.0000, C_0 = 0.0000)"
 elif slug=='hash-tables-collision-resolution':
  val=f['m']*c['resultScale']
  return f"k_hash = m = {fmt(val,c['resultDecimals'])} probes/interval; Intercept P_0 = {fmt(f['b'],c['resultDecimals'])} probes (theoretical k_hash = 1.0000, P_0 = 0.0000)"
 elif slug=='graph-traversal-shortest-paths':
  val=f['m']*c['resultScale']
  return f"k_graph = m = {fmt(val,c['resultDecimals'])} operations/vertex; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} operations (theoretical k_graph = 5.0000, T_0 = 0.0000)"
 elif slug=='dynamic-programming-memoization':
  val=f['m']*c['resultScale']
  return f"k_dp = m = {fmt(val,c['resultDecimals'])} states/item; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} states (theoretical k_dp = 100.0000, T_0 = 0.0000)"
 elif slug=='greedy-minimum-spanning-trees':
  val=f['m']*c['resultScale']
  return f"k_mst = m = {fmt(val,c['resultDecimals'])} lookups/vertex; Intercept Q_0 = {fmt(f['b'],c['resultDecimals'])} lookups (theoretical k_mst = 8.0000, Q_0 = 0.0000)"
 elif slug=='string-matching-automata':
  val=f['m']*c['resultScale']
  return f"k_kmp = m = {fmt(val,c['resultDecimals'])} comparisons/char; Intercept C_0 = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical k_kmp = 1.0000, C_0 = 20.0000)"
 elif slug=='network-flow-max-cut':
  val=f['m']*c['resultScale']
  return f"k_flow = m = {fmt(val,c['resultDecimals'])} inspections/vertex; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} inspections (theoretical k_flow = 10.0000, T_0 = 0.0000)"
 elif slug=='trie-prefix-trees':
  val=f['m']*c['resultScale']
  return f"k_trie = m = {fmt(val,c['resultDecimals'])} dereferences/char; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} dereferences (theoretical k_trie = 1.0000, T_0 = 1.0000)"
 elif slug=='huffman-coding-compression':
  val=f['m']*c['resultScale']
  return f"L_bar = m = {fmt(val,c['resultDecimals'])} bits/symbol; Intercept B_0 = {fmt(f['b'],c['resultDecimals'])} bits (theoretical L_bar = 2.5000, B_0 = 64.0000)"
 elif slug=='computational-geometry-convex-hull':
  val=f['m']*c['resultScale']
  return f"k_ccw = m = {fmt(val,c['resultDecimals'])} tests/point; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} tests (theoretical k_ccw = 2.0000, T_0 = 0.0000)"
 elif slug=='backtracking-n-queens-sat':
  val=f['m']*c['resultScale']
  return f"k_bit = m = {fmt(val,c['resultDecimals'])} operations/queen; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} operations (theoretical k_bit = 4.0000, T_0 = 0.0000)"
 elif slug=='b-tree-disk-indexing':
  val=f['m']*c['resultScale']
  return f"k_node = m = {fmt(val,c['resultDecimals'])} comparisons/level; Intercept C_0 = {fmt(f['b'],c['resultDecimals'])} comparisons (theoretical k_node = 8.0000, C_0 = 0.0000)"
 elif slug=='fast-fourier-transform':
  val=f['m']*c['resultScale']
  return f"k_fft = m = {fmt(val,c['resultDecimals'])} butterflies/(N log₂ N); Intercept B_0 = {fmt(f['b'],c['resultDecimals'])} butterflies (theoretical k_fft = 0.5000, B_0 = 0.0000)"
 elif slug=='a-star-pathfinding-heuristics':
  val=f['m']*c['resultScale']
  return f"k_astar = m = {fmt(val,c['resultDecimals'])} expansions/grid-step; Intercept E_0 = {fmt(f['b'],c['resultDecimals'])} expansions (theoretical k_astar = 3.0000, E_0 = 0.0000)"
 elif slug=='lru-cache-replacement':
  val=f['m']*c['resultScale']
  return f"k_lru = m = {fmt(val,c['resultDecimals'])} hits/cache-frame; Intercept H_0 = {fmt(f['b'],c['resultDecimals'])} hits (theoretical k_lru = 6.0000, H_0 = 0.0000)"
 elif slug=='cryptographic-rsa-modular':
  val=f['m']*c['resultScale']
  return f"k_mod = m = {fmt(val,c['resultDecimals'])} operations/bit; Intercept M_0 = {fmt(f['b'],c['resultDecimals'])} operations (theoretical k_mod = 1.5000, M_0 = 0.0000)"
 elif slug=='concurrency-synchronization-deadlock':
  val=f['m']*c['resultScale']
  return f"k_sync = m = {fmt(val,c['resultDecimals'])} operations/thread; Intercept S_0 = {fmt(f['b'],c['resultDecimals'])} operations (theoretical k_sync = 4.0000, S_0 = 0.0000)"
 elif slug=='relational-query-optimization':
  val=f['m']*c['resultScale']
  return f"k_join = m = {fmt(val,c['resultDecimals'])} comparisons/tuple; Intercept T_0 = {fmt(f['b'],c['resultDecimals'])} operations (theoretical k = 2.0000, T_0 = 0.0000)"
 return ""

def worked(c,row):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  n=row['input']
  log2n=row['x']
  c_max=row['raw']
  return f"Array Size n = {int(n)} keys; Key Entropy log₂(n) = log₂({int(n)}) = {log2n:.4f} bits.\nWorst-Case Binary Search Key Comparisons: C_max = ⌊log₂(n)⌋ + 1 = ⌊{log2n:.4f}⌋ + 1 = {c_max} comparisons.\nVerification: At each step, remaining search space halves from {int(n)} ⟶ {int(n)//2} ⟶ {int(n)//4} ... terminating in exactly {c_max} iterations."
 elif slug=='quadratic-sorting-algorithms':
  n=row['input']
  x_pairs=row['x']
  c_ops=row['raw']
  return f"Array Size n = {int(n)} keys; Directed Pair Space n(n − 1) = {int(n)} × {int(n)-1} = {int(x_pairs)} pairs.\nTotal Unordered Pairs to Compare: C = n(n − 1) / 2 = {int(x_pairs)} / 2 = {c_ops} comparisons.\nVerification: In each pass i from 0 to n−2, exactly n − 1 − i comparisons occur: (n−1) + (n−2) + ... + 1 = {c_ops} comparisons."
 elif slug=='divide-conquer-sorting':
  n=row['input']
  log2n=math.log2(n)
  x_space=row['x']
  c_ops=row['raw']
  return f"Array Size n = {int(n)} keys; Recursion Tree Depth h = log₂({int(n)}) = {int(log2n)} levels.\nRecursive Interval Space: x = n(log₂ n − 1) = {int(n)} × ({int(log2n)} − 1) = {int(x_space)} intervals.\nWorst-Case Key Comparisons: C_merge = n·log₂(n) − n + 1 = {int(n)} × {int(log2n)} − {int(n)} + 1 = {c_ops} comparisons.\nVerification: At depth j in [0 .. {int(log2n)-1}], exactly 2^j subarrays of size {int(n)}/2^j are merged with at most (size − 1) comparisons per subproblem."
 elif slug=='stack-adt-recursion':
  n=row['input']
  depth=row['x']
  mem_bytes=row['raw']
  return f"Recursion Depth n = {int(n)} frames; Active Activation Records = {int(depth)} frames.\nPeak Call Stack Memory Consumption: M(n) = F_frame · n + M_0 = 64 × {int(n)} + 128 = {mem_bytes} bytes ({mem_bytes/1024:.2f} KiB).\nVerification: Each physical activation record allocates 64 bytes on the thread stack segment (8B return address + 8B saved RBP + 16B saved registers + 32B local variables), moving RSP downward by exactly {mem_bytes - 128} bytes from the initial 128-byte runtime CRT base frame."
 elif slug=='queue-buffer-management':
  n=row['input']
  pkts=row['x']
  vol_bytes=row['raw']
  return f"Packet Batch Size n = {int(n)} packets; Circular Array Capacity = 12 slots.\nCumulative Buffer Memory Bus Transfer Volume: V(n) = L_packet · n + V_0 = 64 × {int(n)} + 256 = {vol_bytes} bytes ({vol_bytes/1024:.2f} KiB).\nVerification: Each streamed network packet transfers a 64-byte payload (one full CPU cache line) into the ring slot on enqueue and reads 64 bytes on dequeue, executing {int(n)//12} full cyclic pointer wrap-arounds plus an initial 256-byte cache-line padded descriptor control header."
 elif slug=='linked-list-architectures':
  n=row['input']
  nodes=row['x']
  mem_bytes=row['raw']
  return f"List Length n = {int(n)} nodes; Active Dynamic Heap Nodes = {int(nodes)} nodes.\nTotal Allocated Heap Memory: M(n) = S_node · n + M_0 = 32 × {int(n)} + 64 = {mem_bytes} bytes ({mem_bytes/1024:.2f} KiB).\nVerification: Each doubly linked list node allocates 32 bytes on the 64-bit heap (8B data payload + 8B next pointer + 8B prev pointer + 8B malloc 16-byte boundary alignment padding), plus 64 bytes for dual dummy sentinels (Sentinel Head = 32B, Sentinel Tail = 32B)."
 elif slug=='binary-search-trees':
  n=row['input']
  log2n=row['x']
  h_val=row['raw']
  return f"Dataset Scale n = {int(n)} keys; Logarithmic Key Entropy x = log₂({int(n)}) = {log2n:.4f} bits.\nBalanced Binary Search Tree Height: h(n) = ⌊log₂(n)⌋ + 1 = ⌊{log2n:.4f}⌋ + 1 = {h_val} levels.\nVerification: At depth d in [0 .. {h_val-1}], a full binary tree accommodates at most 2^d nodes, yielding maximum cumulative capacity ∑_{{d=0}}^{{{h_val-1}}} 2^d = 2^{h_val} − 1 = {2**h_val - 1} nodes, which strictly encloses n = {int(n)} keys."
 elif slug=='binary-heaps-priority-queues':
  n=row['input']
  log2n=math.log2(n)
  x_space=row['x']
  c_comps=row['raw']
  return f"Array Size n = {int(n)} keys; Logarithmic Tree Height h = ⌊log₂({int(n)})⌋ + 1 = {int(log2n)+1} levels.\nCumulative Sift Interval Space: x = n − log₂(n) = {int(n)} − {int(log2n)} = {x_space:.4f} intervals.\nWorst-Case Floyd Heapify Comparisons: C(n) = 2(n − log₂ n) = 2 × ({int(n)} − {int(log2n)}) = {c_comps} comparisons.\nVerification: Non-leaf nodes from index ⌊n/2⌋ − 1 down to 0 are sifted down; summing 2 comparisons per level across all node heights converges to strictly 2(n − log₂ n) operations."
 elif slug=='hash-tables-collision-resolution':
  n=row['input']
  m_cap=1000.0
  alpha=float(n)/m_cap
  x_coord=row['x']
  p_probes=row['raw']
  return f"Table Capacity m = 1000 slots; Key Dataset Size n = {int(n)} keys; Load Factor α = {int(n)} / 1000 = {alpha:.4f}.\nTransformed Load Coordinate: x = 1 / (1 − α) = 1 / (1 − {alpha:.4f}) = {x_coord:.4f}.\nExpected Unsuccessful Search Probe Depth: E[P] = 1 / (1 − α) = {p_probes:.4f} memory probes.\nVerification: Under uniform hashing, the probability of requiring at least i probes is α^(i-1); summing the geometric tail series ∑_{{j=0}}^∞ α^j yields strictly 1 / (1 − α) = {p_probes:.4f} probes."
 elif slug=='graph-traversal-shortest-paths':
  v=row['input']
  e=4.0*float(v)
  t_ops=row['raw']
  return f"Network Vertices |V| = {int(v)} vertices; Average Out-Degree d = 4.0 edges/vertex; Total Edges |E| = 4 × {int(v)} = {int(e)} edges.\nTotal Elementary Traversal Operations: T(|V|) = |V| + |E| = {int(v)} + {int(e)} = {t_ops} operations.\nVerification: In an Adjacency List representation, BFS and DFS discover and push every reachable vertex exactly once ({int(v)} vertex visits) and inspect every incident directed edge exactly once ({int(e)} edge scans), converging to strictly |V| + |E| = 5·|V| = {t_ops} operations."
 elif slug=='dynamic-programming-memoization':
  n=row['input']
  w_cap=100.0
  t_states=row['raw']
  return f"Item Count n = {int(n)} items; Knapsack Capacity W = 100 weight units; Total Subproblem Grid Cells (n × W) = {int(n)} × 100 = {t_states} states.\nTotal Elementary State Transitions: T(n) = W · n = 100 × {int(n)} = {t_states} state evaluations.\nVerification: Bottom-up 2D tabulation iterates through i in [1 .. {int(n)}] and w in [0 .. 100], evaluating the Bellman optimality recurrence DP[i][w] = max(DP[i-1][w], DP[i-1][w - w_i] + v_i) in exactly Θ(1) arithmetic operations per cell, converging to strictly 100·n = {t_states} operations."
 elif slug=='greedy-minimum-spanning-trees':
  v=row['input']
  e=4.0*float(v)
  q_lookups=row['raw']
  mst_edges=int(v)-1
  return f"Network Vertices |V| = {int(v)} vertices; Candidate Edges |E| = 4 × {int(v)} = {int(e)} edges; MST Tree Branches |E_mst| = |V| − 1 = {mst_edges} edges.\nTotal Disjoint Set Representative Queries: Q(|V|) = 2|E| = 2 × {int(e)} = {q_lookups} lookups.\nVerification: For every candidate edge (u, v) in the sorted edge pool, Kruskal's algorithm invokes Find(u) and Find(v) to test component root equality, performing exactly 2 queries per edge. Across {int(e)} edges, this yields strictly 2 × 4|V| = 8|V| = {q_lookups} lookups."
 elif slug=='string-matching-automata':
  n=row['input']
  m_pat=20
  c_comps=row['raw']
  return f"Text Stream Length n = {int(n)} chars; Pattern Length m = {m_pat} chars; Precomputed Failure Array π[0..19] = 20 entries.\nTotal Character Comparisons: C(n) = k_kmp · n + C_0 = 1.0000 × {int(n)} + 20 = {c_comps} comparisons.\nVerification: The text pointer i strictly increments from 0 to {int(n)-1} without ever decrementing ({int(n)} stream evaluations). Adding C_0 = m = 20 comparisons for precomputing the π-failure function yields strictly {int(n)} + 20 = {c_comps} operations."
 elif slug=='network-flow-max-cut':
  v=row['input']
  e=3.0*float(v)
  t_insps=row['raw']
  return f"Network Vertices |V| = {int(v)} vertices; Candidate Edges |E| = 3 × {int(v)} = {int(e)} edges; Layered BFS Traversal Units = |V| + |E| = 4·|V| = {int(4*float(v))} operations.\nTotal Residual Graph Augmenting Inspections: T(|V|) = 2.5 × (|V| + |E|) = 10 × {int(v)} = {t_insps} inspections.\nVerification: The Edmonds-Karp solver executes BFS augmenting path searches in the residual graph G_f, exploring admissible forward and backward edges until capacity saturation. Across source-sink saturation passes, this converges to strictly 10·|V| = {t_insps} inspections."
 elif slug=='trie-prefix-trees':
  l=row['input']
  t_derefs=row['raw']
  return f"Query Prefix Key Length L = {int(l)} characters; Root Sentinel Node = 1 dereference; Internal Edge Transitions = {int(l)} child dereferences.\nTotal Path Pointer Dereferences: T(L) = k_trie · L + T_0 = 1.0000 × {int(l)} + 1 = {t_derefs} dereferences.\nVerification: Traversal initiates at the root sentinel node (consuming 1 initial pointer inspection) and sequentially dereferences exactly one child pointer for each character in the query string from index 0 to {int(l)-1}, concluding in strictly L + 1 = {int(l)} + 1 = {t_derefs} dereferences."
 elif slug=='huffman-coding-compression':
  n=row['input']
  b_bits=row['raw']
  ascii_bits=8*int(n)
  saved_pct=(1.0 - float(b_bits)/ascii_bits)*100.0
  return f"Raw Input Stream Length n = {int(n)} symbols; Alphabet |Σ| = 8 symbols; Fixed-Width ASCII Size = 8 × {int(n)} = {ascii_bits} bits.\nCompressed Bitstream Size: B(n) = L_bar · n + B_0 = 2.5000 × {int(n)} + 64 = {b_bits} bits (Compression Savings: {saved_pct:.2f}%).\nVerification: The Huffman encoder emits an average of L_bar = 2.5000 bits per input symbol across the {int(n)} stream symbols ({int(2.5*float(n))} payload bits). Adding B_0 = 64 bits for the 8-entry canonical codebook header yields strictly 2.5·n + 64 = {b_bits} bits."
 elif slug=='computational-geometry-convex-hull':
  n=row['input']
  t_tests=row['raw']
  return f"Planar Point Set Size n = {int(n)} points; Stack Pushes = {int(n)} operations; Maximum Stack Pops = {int(n)} operations.\nTotal 2D Cross-Product Orientation Tests: T(n) = k_ccw · n + T_0 = 2.0000 × {int(n)} + 0 = {t_tests} tests.\nVerification: In the perimeter scan phase of Graham's algorithm, each point is pushed onto the candidate hull stack exactly once ({int(n)} pushes) and can be popped at most once upon detecting clockwise turns (at most {int(n)} pops), bounding total cross-product orientation evaluations to strictly 2·n = {t_tests} tests."
 elif slug=='backtracking-n-queens-sat':
  n=row['input']
  t_ops=row['raw']
  return f"Chessboard Dimension N = {int(n)} queens; Decision Path Depth = {int(n)} levels; Atomic Bitwise Operations per Row = 4 ops.\nTotal Bitmask Register Operations: T(N) = k_bit · N + T_0 = 4.0000 × {int(n)} + 0 = {t_ops} operations.\nVerification: At each row level k ∈ [1..N], the bitmask backtracking engine executes 4 fundamental register operations: (1) collision mask synthesis occupied = cols | diag_left | diag_right; (2) free square isolation available = (~occupied) & ((1 << N) - 1); (3) two's complement lowest-bit extraction bit = available & (-available); and (4) register propagation (cols | bit, (diag_left | bit) << 1, (diag_right | bit) >> 1), yielding strictly 4·N = {t_ops} operations per completed path."
 elif slug=='b-tree-disk-indexing':
  h=row['input']
  c_cmps=row['raw']
  return f"B+ Tree Height h = {int(h)} levels; Page Block Size = 4096 bytes; Fanout Order m = 256; Keys per Node = 255 keys.\nTotal In-Node Key Comparisons: C(h) = k_node · h + C_0 = 8.0000 × {int(h)} + 0 = {c_cmps} comparisons.\nVerification: At each of the {int(h)} tree levels, the database engine loads exactly one 4KB disk page into the buffer pool and performs in-page binary search over the 255 sorted keys. Because log₂(255 + 1) = log₂(256) = 8 comparisons are executed per node, the search path incurs strictly 8·h = {c_cmps} scalar key comparisons."
 elif slug=='fast-fourier-transform':
  n=row['input']
  b_ops=row['raw']
  log2n=int(round(math.log2(n)))
  x_units=int(round(n * log2n))
  return f"Transform Length N = {int(n)} points; Binary Decomposition Depth log₂(N) = {log2n} stages; Butterflies per Stage N/2 = {int(n//2)} butterflies.\nTotal Radix-2 Butterfly Operations: B(N) = k_fft · (N log₂ N) + B_0 = 0.5000 × {x_units} + 0 = {b_ops} butterflies.\nVerification: The Cooley-Tukey decimation-in-time algorithm partitions the {int(n)}-point DFT across exactly {log2n} stages. Each stage updates all {int(n)} array values in pairs, executing exactly {int(n//2)} butterfly kernels. Multiplying {int(n//2)} butterflies/stage by {log2n} stages yields strictly (N/2)log₂(N) = {b_ops} butterfly operations."
 elif slug=='a-star-pathfinding-heuristics':
  d=row['input']
  e_nodes=row['raw']
  return f"Optimal Path Distance D = {int(d)} grid steps; Heuristic Metric = Manhattan L1; Step Expansion Factor = 3.0000.\nTotal Closed Set Node Expansions: E(D) = k_astar · D + E_0 = 3.0000 × {int(d)} + 0 = {e_nodes} expansions.\nVerification: In a 4-connected grid environment guided by an admissible and consistent Manhattan distance heuristic h(n) = |Δx| + |Δy|, the A* evaluation function f(n) = g(n) + h(n) restricts state exploration to a directional corridor along the direct path. At each step along the D-step trajectory, the algorithm expands exactly the on-path vertex and evaluates its 2 orthogonal lateral neighbor candidates before advancing forward, bounding total closed set expansions strictly to 3·D = {e_nodes} nodes."
 elif slug=='lru-cache-replacement':
  c_val=row['input']
  h_hits=row['raw']
  return f"Cache Frame Capacity C = {int(c_val)} frames; Total References N = 200 requests; Working Set Size = 32 pages.\nTotal In-Memory Cache Hits: H(C) = k_lru · C + H_0 = 6.0000 × {int(c_val)} + 0 = {h_hits} hits (Hit Ratio h = {(h_hits/200.0)*100.0:.1f}%).\nVerification: Under Denning's working set model across an execution epoch of 200 memory references, each physical frame allocated to the LRU cache captures an additional 6 recurring loop memory accesses. Across {int(c_val)} allocated frames, the doubly-linked hash map retains these active working set pages, yielding strictly 6·C = {h_hits} cache hits with zero page fault penalties."
 elif slug=='cryptographic-rsa-modular':
  b_bits=row['input']
  m_ops=row['raw']
  return f"Private Key Exponent Length B = {int(b_bits)} bits; Modular Squarings = {int(b_bits)} squarings; Modular Multiplications = {int(b_bits//2)} multiplications.\nTotal Modular Operations: M(B) = k_mod · B + M_0 = 1.5000 × {int(b_bits)} + 0 = {m_ops} operations.\nVerification: The Square-and-Multiply algorithm evaluates modular powers by scanning the binary representation of the exponent from left to right. Every bit unconditionally triggers 1 modular squaring ({int(b_bits)} squarings), while bits with value 1 (averaging 50% in cryptographic keys) trigger 1 modular multiplication ({int(b_bits//2)} multiplications), yielding strictly 1.5·B = {m_ops} modular arithmetic operations."
 elif slug=='concurrency-synchronization-deadlock':
  n_threads=row['input']
  s_ops=row['raw']
  return f"Concurrency Worker Threads N = {int(n_threads)} philosophers; Shared Mutex Locks = {int(n_threads)} forks; Synchronization Policy = Dijkstra Resource Hierarchy.\nTotal Atomic Operations: S(N) = k_sync · N + S_0 = 4.0000 × {int(n_threads)} + 0 = {s_ops} operations.\nVerification: In each dining cycle, each philosopher thread executes exactly 4 atomic synchronization primitives: wait(fork_low), wait(fork_high), signal(fork_low), and signal(fork_high). Across all {int(n_threads)} threads, Dijkstra's asymmetric resource hierarchy eliminates Circular Wait, completing all critical sections with strictly 4·N = {s_ops} atomic operations and zero deadlocks."
 elif slug=='relational-query-optimization':
  n_tuples=row['input']
  t_ops=row['raw']
  return f"Relation Cardinality N = {int(n_tuples)} tuples; Join Algorithm = In-Memory Hash Join; Build Tuples |R| = {int(n_tuples)}; Probe Tuples |S| = {int(n_tuples)}.\nTotal Tuple Operations: T(N) = k_join · N + T_0 = 2.0000 × {int(n_tuples)} + 0 = {t_ops} operations.\nVerification: The build phase evaluates the hash function and inserts each of the {int(n_tuples)} tuples from relation R into hash buckets ({int(n_tuples)} build insertions). The probe phase evaluates hash values for all {int(n_tuples)} tuples from relation S and inspects matching bucket entries ({int(n_tuples)} probe comparisons). Under uniform hashing with unique keys, this converges to strictly 2·N = {t_ops} tuple operations."
 return ""

def uncertainty_text(c):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  return (
   "In deterministic comparison-based algorithm analysis, the theoretical worst-case operation count C_max(n) = ⌊log₂ n⌋ + 1 is an exact mathematical invariant. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal fluctuation, or calibration drift in counting atomic discrete machine instructions. "
   "However, in physical semiconductor computers, wall-clock execution latency deviates from pure mathematical comparison counts due to hardware microarchitectural phenomena: "
   "(1) L1/L2/L3 cache line hierarchy fills and Translation Lookaside Buffer (TLB) virtual memory page walks; "
   "(2) Branch predictor mispredictions in conditional jumps (`if (A[mid] < K)`), which flush deep 14-to-20 stage microprocessor execution pipelines and incur 15 to 20 cycle stalls; "
   "(3) Hardware spatial prefetchers, which optimize sequential linear access patterns over random binary bisections for small arrays (n ≤ 64); and "
   "(4) Operating system preemptive kernel scheduling interrupts and thread context switches. "
   "Ordinary least-squares regression across systematically doubled array sizes n in [64, 4096] extracts the fundamental scaling multiplier k_search = 1.0000 comparisons/bit with zero residual variance (R² = 1.00000), verifying the asymptotic divide-and-conquer bound Θ(log₂ n) with mathematical certitude."
  )
 elif slug=='quadratic-sorting-algorithms':
  return (
   "In combinatorial sorting analysis, the comparison count C(n) = n(n − 1)/2 for Selection Sort and worst-case Bubble Sort is an exact deterministic combinatorial identity. "
   "Unlike noisy analog experimental instrumentation, discrete step counting in virtual machine execution registers exhibits zero random measurement error. "
   "However, physical hardware execution is influenced by microarchitectural phenomena: "
   "(1) L1 data cache spatial locality, where contiguous in-place array iterations execute with ~1 ns latency; "
   "(2) Branch predictor mispredictions during conditional element checks (`if (A[j] < A[min])`), which stall superscalar execution pipelines by 15–20 clock cycles; "
   "(3) Memory bus write contention during element swaps, where Selection Sort's O(n) write profile heavily outperforms Bubble Sort's O(n²) write churn; and "
   "(4) CPU dynamic frequency scaling under continuous nested-loop arithmetic. "
   "Ordinary least-squares linear regression of observed comparisons against permutation pair space x = n(n − 1) yields an empirical scaling slope a_quad = 0.5000 comparisons/pair with zero residual error (R² = 1.00000), rigorously verifying the quadratic complexity bound Θ(n²)."
  )
 elif slug=='divide-conquer-sorting':
  return (
   "In divide-and-conquer algorithmic complexity analysis, the comparison count C_merge(n) = n·log₂(n) − n + 1 for an array of size n = 2^k is an exact deterministic mathematical identity. "
   "Unlike continuous physical instrumentation, discrete operation counting in virtual machine execution registers exhibits zero random measurement noise. "
   "However, in physical microprocessor hardware, wall-clock execution latency deviates from pure mathematical comparison counts due to hardware microarchitectural phenomena: "
   "(1) Memory bus bandwidth contention during auxiliary scratchpad allocation and array copying, where Merge Sort copies 2n elements per level; "
   "(2) L1/L2/L3 cache line evictions when the working array size exceeds the CPU cache capacity (typically > 32 KB for L1); "
   "(3) Branch predictor mispredictions during the dual-pointer merge loop (`if (A[p1] <= A[p2])`), which flush deep execution pipelines; and "
   "(4) Call stack frame allocation overhead and register spilling during recursive bisections. "
   "Ordinary least-squares linear regression of observed comparisons against recursive interval space x = n(log₂ n − 1) yields an empirical scaling slope k_merge = 1.0000 comparisons/interval with zero residual error (R² = 1.00000), rigorously verifying the divide-and-conquer complexity bound Θ(n log₂ n)."
  )
 elif slug=='stack-adt-recursion':
  return (
   "In microarchitectural call stack memory analysis, the activation record size F_frame = 64 bytes per frame under the System V AMD64 ABI is an exact deterministic specification. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal fluctuation, or calibration drift in measuring discrete byte displacements of the hardware stack pointer RSP. "
   "However, in physical microprocessor execution, observable call stack latency and operating system memory footprint are modulated by hardware and kernel mechanisms: "
   "(1) Virtual memory demand paging and Translation Lookaside Buffer (TLB) misses, where physical 4 KiB memory pages are committed only when the stack pointer crosses a page boundary; "
   "(2) CPU L1 data cache line fills and dirty writeback traffic, as stack pushes write to memory lines while stack pops invalidate or reuse warm cache lines; "
   "(3) Compiler optimizations such as leaf function frame elision, tail-call elimination (which reuses the current frame instead of allocating a new one), and register variable allocation; and "
   "(4) Operating system stack canary guard pages, which trigger a kernel page fault (SIGSEGV) if stack depth expands beyond the designated thread memory quota (typically 8 MiB). "
   "Ordinary least-squares linear regression of peak stack memory allocation against recursion depth n in [128, 8192] frames yields an empirical frame scaling slope F_frame = 64.0000 bytes/frame with zero residual error (R² = 1.00000), verifying the linear call stack memory bound Θ(n) with mathematical precision."
  )
 elif slug=='queue-buffer-management':
  return (
   "In systems-level circular buffer analysis, the packet unit payload size L_packet = 64 bytes is an exact hardware specification corresponding to a standard CPU cache line. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete memory bus transfer transactions. "
   "However, in physical multi-core processor execution, observable queue latency and memory bus throughput are modulated by microarchitectural phenomena: "
   "(1) False sharing between producer and consumer processor cores when head and tail pointers share an unpadded 64-byte cache line, causing inter-core MESI cache invalidation ping-pong; "
   "(2) CPU L1 data cache prefetcher stride detection, where sequential circular slot accesses achieve near-100% L1 cache hits (~1 ns latency); "
   "(3) Memory controller bus saturation during sustained burst transfers exceeding DRAM channel bandwidth; and "
   "(4) Operating system scheduler thread preemption and mutex lock-contention latency during buffer full/empty boundary synchronization. "
   "Ordinary least-squares linear regression of observed memory transfer volume against packet batch count n in [256, 16384] packets yields an empirical payload scaling slope L_packet = 64.0000 bytes/packet with zero residual error (R² = 1.00000), verifying the linear queue throughput bound Θ(n) with mathematical precision."
  )
 elif slug=='linked-list-architectures':
  return (
   "In 64-bit systems architecture analysis, the doubly linked list node footprint S_node = 32 bytes and dual sentinel baseline M_0 = 64 bytes are deterministic structural invariants under standard 16-byte heap allocator alignment. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in measuring discrete dynamic heap memory allocation. "
   "However, in physical semiconductor processors, operational traversal latency across linked list structures is heavily modulated by microarchitectural memory hierarchy dynamics: "
   "(1) Pointer chasing cache line misses: because nodes are dynamically allocated at arbitrary, non-contiguous heap addresses, sequential node hops (node = node->next) suffer cold L1/L2 data cache misses (~100–250 CPU cycles per DRAM access) compared to contiguous vectors (~1–4 cycles for L1 cache lines); "
   "(2) Hardware spatial prefetcher failure: CPUs feature hardware stream prefetchers that detect regular linear access strides (e.g. index i to i+1 in arrays), but fail to anticipate non-deterministic heap pointer dereferences; "
   "(3) Dynamic memory allocator chunk header overhead: standard dlmalloc and ptmalloc implementations prepend an 8-to-16-byte chunk header (storing size and in-use flags) to every allocated block, increasing real memory bus consumption; and "
   "(4) Pointer overhead ratio: for an 8-byte payload, a 32-byte doubly linked node imposes a 300% pointer overhead (24 bytes metadata per 8 bytes payload), compared to 0% overhead in dense contiguous arrays. "
   "Ordinary least-squares linear regression of total allocated heap memory against list length n in [128, 8192] nodes yields an empirical node scaling slope S_node = 32.0000 bytes/node with zero residual error (R² = 1.00000), verifying the linear heap memory footprint bound Θ(n) with mathematical precision."
  )
 elif slug=='binary-search-trees':
  return (
   "In discrete tree algorithm analysis, the minimum height h_min(n) = ⌊log₂ n⌋ + 1 of a complete balanced binary search tree is an exact combinatorial invariant derived from decision tree entropy. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete tree levels or key comparisons. "
   "However, in physical semiconductor microprocessors, tree traversal latency and memory access time deviate from idealized theoretical models due to memory hierarchy and pipeline dynamics: "
   "(1) Pointer chasing cache line misses: because child nodes reside at non-contiguous heap addresses, descending each level (node = (k < node->key) ? node->left : node->right) incurs cold CPU L1/L2 data cache stalls (~100–250 CPU cycles) once dataset size exceeds cache capacity; "
   "(2) Hardware spatial prefetcher failure: stream prefetchers excel at sequential array scans but cannot predict non-linear pointer dereferences, giving contiguous vectors a massive practical advantage over pointer-based trees; "
   "(3) Branch predictor mispredictions in inner key comparisons, which stall superscalar execution pipelines by 15–20 clock cycles; and "
   "(4) Insertion order asymmetry: in unaugmented binary search trees, sorted or pathological sequences cause catastrophic tree collapse into a singly-linked list of height h = n, increasing search latency by over 300×. "
   "Ordinary least-squares linear regression of observed tree height against logarithmic key entropy x = log₂(n) across systematically doubled scales n in [64, 4096] yields an empirical height scaling slope alpha = 1.0000 levels/bit with zero residual error (R² = 1.00000), verifying the logarithmic height bound Θ(log₂ n) with mathematical certitude."
  )
 elif slug=='binary-heaps-priority-queues':
  return (
   "In discrete priority queue complexity analysis, the worst-case key comparison count C(n) = 2(n − log₂ n) for in-place bottom-up Floyd heapify is an exact combinatorial identity for power-of-two arrays. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete Machine key comparisons. "
   "However, in physical semiconductor microprocessors, wall-clock heap execution latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) Pointer chasing cache line misses: as elements sink down deep heaps, child index doubling (i ⟶ 2i + 1, 2i + 2) hops across non-contiguous memory pages once heap size exceeds CPU L1/L2 data cache capacity; "
   "(2) Hardware stream prefetcher stall: sequential prefetchers fail to anticipate geometric index bisections, causing Heapsort to run 2× to 3× slower than Quicksort despite matching O(n log n) complexity; "
   "(3) Branch predictor mispredictions during child selection comparisons (`if (A[2i+1] > A[2i+2])`), which flush deep superscalar pipelines; and "
   "(4) D-ary heap trade-offs: 4-way heaps cut tree height in half and pack 4 children into a single 64-byte cache line, significantly reducing cache stall cycles. "
   "Ordinary least-squares linear regression of heapify comparisons against cumulative sift interval space x = n − log₂(n) yields an empirical scaling slope k_heap = 2.0000 comparisons/interval with zero residual variance (R² = 1.00000), verifying Floyd's linear O(n) construction bound with mathematical precision."
  )
 elif slug=='hash-tables-collision-resolution':
  return (
   "In discrete hash table analysis, the expected unsuccessful search probe depth E[P] = 1 / (1 − α) under the Uniform Hashing Assumption is an exact mathematical expectation. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete memory bucket probes. "
   "However, in physical semiconductor microprocessors, wall-clock hash lookup latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) L1/L2 data cache hit ratios and Translation Lookaside Buffer (TLB) page table walks, where contiguous array buffers (Linear Probing) execute within ~1–4 CPU cycles while non-contiguous pointer dereferencing (Separate Chaining) incurs ~100–250 CPU cycles; "
   "(2) Primary clustering in linear probing, which forces probe paths into contiguous occupied runs and causes quadratic latency degradation E[P] ≈ 0.5(1 + 1/(1-α)²); "
   "(3) Branch predictor mispredictions during probe loop termination checks (`if (table[slot] == NULL)`), which stall superscalar execution pipelines by 15–20 clock cycles; and "
   "(4) Hash function computational overhead, where high-entropy 64-bit avalanche functions (MurmurHash3, SipHash) eliminate bucket resonance at the cost of 5–15 CPU instructions per hash. "
   "Ordinary least-squares linear regression of observed probe lengths against transformed load coordinates x = 1 / (1 − α) yields an empirical scaling slope k_hash = 1.0000 probes/interval with zero residual variance (R² = 1.00000), verifying Knuth's uniform hashing theorem with mathematical certitude."
  )
 elif slug=='graph-traversal-shortest-paths':
  return (
   "In discrete graph algorithm analysis, the elementary operation count T(|V|) = |V| + |E| = 5.0000·|V| for Adjacency List BFS/DFS traversal is an exact combinatorial identity for 4-regular networks. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete vertex queue pushes or edge iterations. "
   "However, in physical semiconductor microprocessors, wall-clock graph traversal latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) Pointer chasing cache line misses: in linked adjacency lists, vertex neighbor sequences reside at non-contiguous heap addresses, causing cold CPU L1/L2 data cache stalls (~100–250 CPU cycles) once graph footprint exceeds cache capacity; "
   "(2) Hardware spatial prefetcher failure: non-linear graph topologies prevent hardware stream prefetchers from predicting memory accesses, giving contiguous Compressed Sparse Row (CSR) arrays a 3× to 5× throughput advantage over linked lists; "
   "(3) Branch predictor mispredictions during neighbor iteration loops and visited bitmask checks (`if (!visited[v])`), which stall superscalar execution pipelines by 15–20 clock cycles; and "
   "(4) Priority queue overhead in Dijkstra's algorithm: min-heap extract_min and decrease_key operations introduce an additional log|V| factor, scaling execution time to O((|V| + |E|) log |V|). "
   "Ordinary least-squares linear regression of observed traversal operations against vertex count |V| across networks from 50 to 1000 vertices yields an empirical scaling slope k_graph = 5.0000 operations/vertex with zero residual variance (R² = 1.00000), verifying the linear time complexity bound Θ(|V| + |E|) with mathematical certitude."
  )
 elif slug=='dynamic-programming-memoization':
  return (
   "In discrete algorithm complexity analysis, the tabulation state evaluation count T(n) = W · n = 100.0000·n for the 0/1 Knapsack Problem is an exact combinatorial invariant under fixed capacity W = 100. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete subproblem matrix cell evaluations. "
   "However, in physical semiconductor microprocessors, wall-clock dynamic programming execution latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) CPU L1/L2 data cache hit ratios and spatial prefetching: contiguous row-major traversal (outer loop i, inner loop w) streams adjacent 8-byte cells into 64-byte L1 cache lines with ~100% prefetcher hit rates (~1–4 CPU cycles/cell), whereas transposed column-major traversal suffers catastrophic cache line thrashing and TLB page misses (~100–250 CPU cycles/cell); "
   "(2) Branch predictor mispredictions during item feasibility checks (`if (w >= w_i)`), which can stall superscalar execution pipelines by 15–20 clock cycles per mispredicted branch; "
   "(3) Memory bus transfer overhead and memory footprint: allocating a full (n + 1) × (W + 1) 2D matrix of 64-bit integers incurs DRAM memory allocation latency, which is eliminated by compressing the table into a single 1D reverse-scanned array of length W + 1 that fits entirely inside the CPU L2 cache; and "
   "(4) Call stack frame overhead in Top-Down Memoization: recursive memoization allocates AMD64 stack frames (48–64 bytes/frame) and incurs non-contiguous pointer dereferencing latency, running 2× to 4× slower than iterative Bottom-Up Tabulation. "
   "Ordinary least-squares linear regression of observed tabulation state evaluations against item count n across problem instances from 10 to 150 items yields an empirical scaling slope k_dp = 100.0000 states/item with zero residual variance (R² = 1.00000), verifying the pseudo-polynomial complexity bound Θ(n·W) with mathematical certitude."
  )
 elif slug=='greedy-minimum-spanning-trees':
  return (
   "In discrete network algorithm analysis, the total Disjoint Set Union query count Q(|V|) = 2|E| = 8.0000·|V| for Kruskal's algorithm is an exact combinatorial invariant for 4-regular edge pools. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete DSU Find representative queries or tree edge admissions. "
   "However, in physical semiconductor microprocessors, wall-clock greedy MST execution latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) Pointer chasing cache line misses during Disjoint Set Union Find traversals: walking parent pointers (parent[u]) across large vertex arrays causes cold L1/L2 data cache stalls (~100–250 CPU cycles) prior to path compression; "
   "(2) Amortized tree flattening via recursive Path Compression: after initial Find operations flatten parent pointers directly to the component root, subsequent queries execute in near-instantaneous L1 cache hit times (<2 CPU cycles); "
   "(3) Sorting subsystem memory bus contention: sorting |E| = 4|V| candidate edges via introsort or quicksort dominates wall-clock time (O(|E| log |E|)), requiring intensive DRAM memory bandwidth; and "
   "(4) Priority queue overhead in Prim's algorithm: maintaining binary min-heap keys introduces O(log |V|) sift latency per edge inspection, rendering Kruskal with DSU significantly faster on sparse graphs. "
   "Ordinary least-squares linear regression of observed DSU queries against vertex count |V| across networks from 50 to 1000 vertices yields an empirical scaling slope k_mst = 8.0000 lookups/vertex with zero residual variance (R² = 1.00000), verifying the asymptotic linear query bound Θ(|V|) with mathematical certitude."
  )
 elif slug=='string-matching-automata':
  return (
   "In discrete string matching algorithm analysis, the character comparison count C(n) = k_kmp · n + C_0 = 1.0000·n + 20.0000 for Knuth-Morris-Pratt scanning is an exact mathematical invariant under uniform text models with pattern length m = 20. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete character equality evaluations in virtual registers. "
   "However, in physical semiconductor microprocessors, wall-clock string search latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) CPU L1/L2 data cache hit ratios and spatial prefetching: sequential text scanning (incrementing pointer i from 0 to n-1) achieves near 100% L1 cache line hit rates (~1 ns latency) as hardware prefetchers stream contiguous 64-byte lines ahead of execution; "
   "(2) Branch predictor mispredictions during mismatch redirection: when character mismatches trigger failure table lookups (`j = pi[j - 1]`), conditional branch instructions (`if (P[j] == T[i])`) can cause pipeline flushes (15–20 CPU cycle penalty) on irregular text; "
   "(3) Sublinear window skipping in Boyer-Moore: on large alphabets, right-to-left scanning skips up to m characters per mismatch via bad-character tables, executing significantly faster than KMP in wall-clock time; and "
   "(4) Hardware SIMD vectorization: modern CPUs utilize AVX-512 and ARM Neon vector instructions (`_mm512_cmpeq_epi8_mask`) to evaluate 64 text characters in a single clock cycle, operating an order of magnitude faster than scalar comparison loops. "
   "Ordinary least-squares linear regression of observed character comparisons against text length n across stream lengths from 500 to 10,000 characters yields an empirical scaling slope k_kmp = 1.0000 comparisons/char with zero residual variance (R² = 1.00000), verifying the asymptotic linear time complexity bound Θ(n + m) with mathematical certitude."
  )
 elif slug=='network-flow-max-cut':
  return (
   "In discrete network flow algorithm analysis, the residual augmenting inspection count T(|V|) = 10.0000·|V| for Edmonds-Karp BFS saturation is an exact combinatorial invariant for 3-regular capacitated networks. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete residual edge inspections or bottleneck capacity comparisons. "
   "However, in physical semiconductor microprocessors, wall-clock network flow execution latency is strongly modulated by memory hierarchy and pipeline dynamics: "
   "(1) Pointer chasing cache line misses during residual graph traversals: alternating between forward edges and backward residual edges causes non-contiguous memory accesses across adjacency lists, stalling CPU execution pipelines when network footprint exceeds L2 cache capacity; "
   "(2) Branch predictor mispredictions during capacity feasibility checks (`if (c_f(u, v) > 0)`): irregular bottleneck capacities cause branch predictor stalls (15–20 CPU cycles) during residual BFS queue expansions; "
   "(3) Algorithmic speedup via Dinic's Level Graphs: Dinic routes multiple augmenting paths simultaneously in a layered DAG, reducing time from O(|V| · |E|²) to O(|V|² · |E|) (and O(|E| √|V|) on unit networks); and "
   "(4) Push-Relabel local height discharge parallelism: Goldberg-Tarjan preflow-push algorithms eliminate global BFS traversals entirely, using local height discharge rules that execute with superior SIMD and multi-core cache locality. "
   "Ordinary least-squares linear regression of observed residual inspections against vertex count |V| across networks from 50 to 1000 vertices yields an empirical scaling slope k_flow = 10.0000 inspections/vertex with zero residual variance (R² = 1.00000), verifying the asymptotic linear inspection bound with mathematical certitude."
  )
 elif slug=='trie-prefix-trees':
  return (
   "In discrete data structure analysis, the trie pointer dereference count T(L) = k_trie · L + T_0 = 1.0000·L + 1.0000 for standard prefix tree traversal is an exact deterministic invariant across key length L. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete pointer dereferences or memory bus loads. "
   "However, in physical semiconductor microprocessors, wall-clock trie retrieval latency is strongly modulated by memory hierarchy and microarchitectural dynamics: "
   "(1) Pointer chasing cache line misses: because child nodes are dynamically allocated at non-contiguous heap memory locations, walking down a naive 256-way trie causes cold L1/L2 data cache stalls (~100–250 CPU cycles per DRAM access) once the trie footprint exceeds cache capacity; "
   "(2) Hardware spatial prefetcher failure: non-linear heap-allocated node links prevent CPU hardware stream prefetchers from predicting memory accesses, causing standard multi-way tries to suffer severe pointer-chasing latency compared to contiguous flat tables; "
   "(3) Node compaction and SIMD acceleration in Adaptive Radix Trees (ART): ART avoids sparse 256-pointer arrays by adapting node capacities (Node4, Node16, Node48, Node256) based on child density, utilizing SIMD vector instructions (_mm_cmpeq_epi8) on Node16 to evaluate 16 character keys in a single clock cycle with zero branch mispredictions; and "
   "(4) Path compression in Patricia Tries: collapsing single-child non-branching node chains into composite substring edges reduces total node traversals by 50% to 80% on sparse key distributions, keeping high-frequency routing prefixes resident in L1/L2 caches. "
   "Ordinary least-squares linear regression of observed pointer dereferences against key length L across queries from 4 to 48 characters yields an empirical scaling slope k_trie = 1.0000 dereferences/char and intercept T_0 = 1.0000 dereferences with zero residual variance (R² = 1.00000), verifying the linear retrieval bound Θ(L) with mathematical certitude."
  )
 elif slug=='huffman-coding-compression':
  return (
   "In discrete information theory and algorithm analysis, the compressed bitstream size B(n) = L_bar · n + B_0 = 2.5000·n + 64.0000 bits for stationary memoryless sources is an exact deterministic mathematical invariant. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal fluctuation, or calibration drift in measuring discrete binary bit counts emitted by software encoders. "
   "However, in physical semiconductor microprocessors, wall-clock compression and decompression throughput are modulated by microarchitectural and memory hierarchy phenomena: "
   "(1) Bit-accumulator register spills and byte alignment: CPUs manipulate 32-bit and 64-bit integer words natively, requiring bitwise shift (`<<`), OR (`|=`), and conditional flush instructions to assemble variable-length codewords into memory buffers, introducing instruction-level serialization; "
   "(2) Branch predictor mispredictions in decoding loops: bit-by-bit tree traversal evaluates conditional branch instructions on unpredictable 0/1 bits, stalling superscalar execution pipelines by 15–20 clock cycles per misprediction; "
   "(3) Cache locality of lookup decoding tables (LUTs): table-driven decoders replace tree walking with direct array lookups (e.g. 10-bit LUTs), which achieve near-100% L1 data cache hits (~1 ns latency) and boost decompression throughput by 4× to 8×; and "
   "(4) Vector SIMD parallel bit manipulation: modern x86-64 and ARM processors leverage AVX2/AVX-512 vector bit-gather (`PEXT`, `PDEP`, `VPERMB`) instructions to encode and decode multiple symbol streams concurrently. "
   "Ordinary least-squares linear regression of observed compressed bit counts against stream length n across inputs from 500 to 50,000 symbols yields an empirical average code length L_bar = 2.5000 bits/symbol and header intercept B_0 = 64.0000 bits with zero residual variance (R² = 1.00000), rigorously verifying the linear entropy scaling bound with mathematical certitude."
  )
 elif slug=='computational-geometry-convex-hull':
  return (
   "In discrete computational geometry and algorithmic analysis, the total orientation test count T(n) = k_ccw · n + T_0 = 2.0000·n + 0.0000 tests during Graham's perimeter scan is an exact amortized invariant. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete 2D cross-product evaluations in CPU ALUs. "
   "However, in physical microprocessor hardware, wall-clock convex hull execution latency and topological robustness are modulated by hardware and numerical mechanisms: "
   "(1) Memory bus bandwidth and sorting hierarchy cache misses: the initial polar angle sorting phase dominates execution time (O(n log n)), causing L1/L2 data cache evictions once point set footprint exceeds cache capacity; "
   "(2) Branch predictor mispredictions during orientation tests (`if (Δ <= 0)`): irregular vertex geometries cause frequent pipeline stalls (15–20 CPU cycles) as the superscalar branch predictor alternates between stack pushes and pops; "
   "(3) IEEE 754 floating-point roundoff errors: near-collinear points can cause sign-flips in determinant evaluations, causing catastrophic topological failures (self-intersecting hulls or infinite loops); and "
   "(4) Exact adaptive precision predicate fallback: robust geometric libraries (e.g., Jonathan Shewchuk's adaptive predicates) use fast hardware floating-point filters, escalating to multiple-precision arithmetic only when determinants fall within precision uncertainty bounds ε. "
   "Ordinary least-squares linear regression of observed orientation evaluations against point set size n across sets from 50 to 5000 points yields an empirical scaling slope k_ccw = 2.0000 tests/point and intercept T_0 = 0.0000 tests with zero residual variance (R² = 1.00000), verifying the linear scan complexity bound Θ(n) with mathematical certitude."
  )
 elif slug=='backtracking-n-queens-sat':
  return (
   "In discrete combinatorial optimization and constraint satisfaction analysis, the bitmask register operation count T(N) = k_bit · N + T_0 = 4.0000·N + 0.0000 operations along any decision path is an exact algorithmic invariant. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete bitwise ALU logic instructions. "
   "However, in physical semiconductor microprocessors, wall-clock backtracking and SAT solving latency are heavily modulated by microarchitectural and memory hierarchy phenomena: "
   "(1) CPU branch predictor misprediction recovery penalties: when exploring deep state space search trees, frequent alternation between successful placements and conflict backtracking stalls superscalar pipelines by 15–20 CPU cycles per branch misprediction; "
   "(2) L1/L2/L3 data cache misses during clause database traversals: in large-scale CDCL SAT solvers with millions of learned clauses, resolving implications along the implication graph causes cold DRAM memory bus stalls (~100–250 CPU cycles) once the clause store exceeds L3 cache capacity; "
   "(3) Microarchitectural acceleration via Two-Watched-Literals (2WL): the 2WL indexing scheme eliminates memory scans across satisfied clauses, visiting clauses only when a watched literal evaluates to False, and allowing instantaneous O(1) backjumping with zero pointer restoration overhead; and "
   "(4) Register allocation and bit-level parallelism: Rich Burroughs' bitmask backtracking algorithm maps board constraints entirely into CPU machine registers, eliminating memory heap allocation and executing up to 25× faster than pointer-based array implementations. "
   "Ordinary least-squares linear regression of observed bitwise register operations against board dimension N across instances from 4 to 16 queens yields an empirical scaling slope k_bit = 4.0000 operations/queen and intercept T_0 = 0.0000 operations with zero residual variance (R² = 1.00000), verifying the linear path complexity bound Θ(N) with mathematical certitude."
  )
 elif slug=='b-tree-disk-indexing':
  return (
   "In external memory algorithms and database indexing analysis, the in-node comparison count C(h) = k_node · h + C_0 = 8.0000·h + 0.0000 comparisons across traversal height h is an exact algorithmic invariant for order m = 256 nodes. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete in-page binary comparisons or block I/O transfers. "
   "However, in physical database storage servers, wall-clock transaction and query latency are heavily modulated by external memory and operating system dynamics: "
   "(1) Database buffer pool cache hit ratios: accessing a page resident in DRAM memory frames consumes ~50–100 ns, whereas a buffer miss requiring an NVMe SSD flash page read incurs 10–50 µs (~500× slower), and a mechanical HDD sector seek incurs 5–10 ms (~100,000× slower); "
   "(2) Operating system page cache double-buffering: databases utilize direct I/O (`O_DIRECT`) to bypass OS kernel page cache replication and avoid double-buffering latency; "
   "(3) Multi-core latch contention on root and internal nodes: concurrent reader/writer transactions cause lock and latch thrashing on high-level routing nodes, resolved via optimistic lock coupling (latch crabbing); and "
   "(4) Sequential leaf scanning vs random in-order traversal: the B+ Tree doubly-linked leaf architecture allows range scans (`WHERE id BETWEEN a AND b`) to stream contiguous pages at multi-gigabyte sequential disk throughput, bypassing upper index levels entirely. "
   "Ordinary least-squares linear regression of observed in-node comparisons against tree height h across depths from 2 to 8 levels yields an empirical scaling slope k_node = 8.0000 comparisons/level and intercept C_0 = 0.0000 comparisons with zero residual variance (R² = 1.00000), verifying the multi-way indexing complexity bound Θ(h) with mathematical certitude."
  )
 elif slug=='fast-fourier-transform':
  return (
   "In discrete Fourier transform analysis and computational algebra, the butterfly operation count B(N) = 0.5000 · N log₂(N) + 0.0000 butterflies is a strict deterministic mathematical invariant for Radix-2 Cooley-Tukey decompositions. "
   "Unlike physical sensor systems, there are no continuous measurement noise, thermal perturbations, or instrument calibration drifts in counting discrete arithmetic butterfly executions. "
   "However, in high-performance computing hardware and DSP microprocessors, wall-clock execution time and numerical accuracy are modulated by computer microarchitecture and floating-point dynamics: "
   "(1) Floating-point round-off error propagation: in IEEE 754 single and double precision floating-point arithmetic, evaluating complex twiddle factor recurrences across log₂(N) stages accumulates rounding errors with an RMS relative norm bounded by O(log₂(N) · ε_machine), where machine epsilon ε ≈ 1.11 × 10⁻¹⁶ for 64-bit floats; "
   "(2) CPU L1/L2/L3 data cache misses and memory stride thrashing: as transform size N increases beyond the L1 data cache capacity (typically 32–64 KB), the power-of-two memory strides (strides of 2^(s-1)) in large butterfly stages cause severe cache line conflicts and TLB stalls unless transpose-based Four-Step or cache-oblivious algorithms are employed; "
   "(3) Twiddle factor look-up table latency vs. runtime trigonometric evaluation: dynamically calling transcendental sin() and cos() functions in inner loops introduces 50–100 clock cycles of latency per butterfly, whereas precomputed look-up tables eliminate trigonometric calls at the expense of memory cache occupancy; and "
   "(4) SIMD register width and vectorization efficiency: modern AVX2 and AVX-512 vector units process 4 to 8 double-precision complex multiply-add (FMA) instructions simultaneously, accelerating butterflies by up to 6× over scalar implementations. "
   "Ordinary least-squares linear regression of observed butterfly executions against the composite complexity coordinate x = N log₂(N) across sample sizes from N = 64 to N = 4096 yields an empirical multiplier k_fft = 0.5000 butterflies/(N log₂ N) and baseline intercept B_0 = 0.0000 butterflies with zero residual variance (R² = 1.00000), verifying the Cooley-Tukey asymptotic complexity bound Θ(N log N) with absolute mathematical certitude."
  )
 elif slug=='a-star-pathfinding-heuristics':
  return (
   "In heuristic search theory and discrete optimization, the closed set node expansion count E(D) = k_astar · D + E_0 = 3.0000·D + 0.0000 expansions across path distance D is an exact algorithmic invariant for consistent Manhattan guidance in uniform grid corridors. "
   "Unlike analog physical experiments, there is no continuous sensor noise, thermal fluctuations, or mechanical wear in counting discrete graph node expansions or priority queue extractions. "
   "However, in practical robotic navigation systems and autonomous game engines, wall-clock pathfinding throughput and memory consumption are heavily modulated by computer microarchitecture and heuristic dynamics: "
   "(1) Priority queue min-heap percolation overhead: in large-scale state spaces with millions of vertices, each decrease-key or insertion operation in the binary min-heap requires O(log |Open|) pointer swaps, incurring CPU cache line misses once the heap exceeds L3 cache capacity; "
   "(2) Heuristic admissibility and consistency violations: utilizing an inadmissible heuristic (h(n) > h*(n)) can accelerate search but forfeits the guarantee of path optimality, while an inconsistent heuristic requires reopening closed nodes, escalating execution time from O(|V| log |V|) to exponential worst-case O(2^|V|); "
   "(3) Tie-breaking strategies on identical f-scores: in open grid maps with many equidistant paths, naive FIFO tie-breaking causes extensive exploration of symmetric paths, whereas tie-breaking in favor of higher g(n) directs the search aggressively along the forward frontier; and "
   "(4) Jump Point Search (JPS) and spatial caching: on uniform-cost grid terrain, JPS prunes symmetric intermediate nodes by jumping directly between obstacle turning points, reducing Open Set operations by up to 95%. "
   "Ordinary least-squares linear regression of observed closed set expansions against optimal path distance D across trials from D = 10 to D = 70 grid steps yields an empirical scaling factor k_astar = 3.0000 expansions/grid-step and intercept E_0 = 0.0000 expansions with zero residual variance (R² = 1.00000), verifying the linear search corridor bound Θ(D) with mathematical certitude."
  )
 elif slug=='lru-cache-replacement':
  return (
   "In operating systems virtual memory analysis and caching theory, the cache hit count H(C) = k_lru · C + H_0 = 6.0000·C + 0.0000 hits across frame capacity C is an exact algorithmic invariant for our standardized localized reference stream. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete cache hits or page fault exceptions. "
   "However, in physical computer architectures and operating system kernels, wall-clock memory access latency and system throughput are heavily modulated by hardware and software dynamics: "
   "(1) Hardware Memory Management Unit (MMU) TLB miss penalties: translating virtual page numbers to physical frame numbers relies on the Translation Lookaside Buffer (TLB); TLB misses require multi-level page table walks in DRAM, adding 20–50 ns of latency per reference; "
   "(2) Secondary storage I/O latency disparity: a cache hit accesses volatile DRAM in ~50–100 ns, whereas a page fault requiring an NVMe SSD flash read incurs 10–50 µs (~500× slower), and a mechanical hard disk seek incurs 5–10 ms (~100,000× slower); "
   "(3) Dirty page writeback overhead: evicting a modified (dirty) page requires flushing its contents synchronously or asynchronously to swap space on disk before the frame can be reallocated, doubling I/O bus traffic relative to clean page evictions; and "
   "(4) Multiprocessor lock contention on cache metadata: in concurrent multicore operating systems, updating doubly-linked list pointers or clock hands requires synchronizing across CPU cores, mitigated in production by segmented LRU (2Q) or lock-free clock buffers. "
   "Ordinary least-squares linear regression of observed cache hits against frame capacity C across instances from C = 4 to C = 28 frames yields an empirical marginal hit rate k_lru = 6.0000 hits/cache-frame and baseline intercept H_0 = 0.0000 hits with zero residual variance (R² = 1.00000), verifying the working set capacity scaling bound Θ(C) with mathematical certitude."
  )
 elif slug=='cryptographic-rsa-modular':
  return (
   "In public-key cryptography and algorithmic number theory, the modular operation count M(B) = k_mod · B + M_0 = 1.5000·B + 0.0000 operations across exponent bit length B is an exact deterministic arithmetic invariant for binary Square-and-Multiply exponentiation. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete modular squarings or multi-precision multiplications. "
   "However, in physical cryptographic hardware and software implementations, wall-clock encryption/decryption latency and security margins are heavily modulated by microarchitectural dynamics: "
   "(1) Multi-precision large-integer limb arithmetic: large integers exceeding the native CPU register width (64 bits) are represented as arrays of 64-bit limbs; multi-precision multiplication scales quadratically as O((B/64)²) under classical Comba multiplication, or O((B/64)^1.58) via Karatsuba multiplication; "
   "(2) Montgomery residue space transformation: standard multi-precision modular division is replaced in production libraries (OpenSSL) by Montgomery multiplication, eliminating quotient division at the expense of initial domain conversion overhead; "
   "(3) Side-channel timing and power analysis vulnerabilities: conditional execution of modular multiplications in naive Square-and-Multiply creates data-dependent timing discrepancies, allowing adversaries to extract private key bits via Simple Power Analysis (SPA); and "
   "(4) Constant-time Montgomery ladder mitigation: production cryptographic security modules implement constant-time exponentiation ladders (executing 1 squaring and 1 multiplication on every bit regardless of bit value) to eliminate side-channel leakage. "
   "Ordinary least-squares linear regression of observed modular operations against exponent bit length B across instances from B = 64 to B = 4096 bits yields an empirical scaling multiplier k_mod = 1.5000 operations/bit and baseline intercept M_0 = 0.0000 operations with zero residual variance (R² = 1.00000), verifying the binary exponentiation complexity bound Θ(B) with mathematical certitude."
  )
 elif slug=='concurrency-synchronization-deadlock':
  return (
   "In concurrent systems and distributed synchronization theory, the atomic operation count S(N) = k_sync · N + S_0 = 4.0000·N + 0.0000 operations across thread count N is an exact deterministic arithmetic invariant for the Dining Philosophers protocol. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete atomic lock acquisitions and semaphore signals. "
   "However, in physical multi-core processors and operating system kernels, wall-clock concurrency throughput and lock contention are heavily modulated by microarchitectural dynamics: "
   "(1) CPU cache coherence protocols and bus locking: atomic Compare-And-Swap (CAS) instructions force the CPU to lock cache lines or memory buses under the MESI/MOESI coherence protocol, incurring 40–100 clock cycles of interconnect latency per contended lock; "
   "(2) Operating system context switch and thread scheduling overhead: when a thread blocks on a contested mutex, the kernel transitions the thread from Running to Waiting and performs a full context switch (saving CPU registers, switching page tables), consuming 1–5 µs of CPU overhead; "
   "(3) Spinlock thresholding vs sleep-locks: hybrid mutexes spin briefly in user space for a few hundred cycles before sleeping, amortizing context-switch overhead for short critical sections; and "
   "(4) Priority inversion on shared synchronization objects: low-priority threads holding locks required by high-priority threads cause systemic stalling unless Priority Inheritance Protocols (PIP) are enabled. "
   "Ordinary least-squares linear regression of observed atomic operations against thread count N across instances from N = 2 to N = 14 threads yields an empirical scaling factor k_sync = 4.0000 operations/thread and baseline intercept S_0 = 0.0000 operations with zero residual variance (R² = 1.00000), verifying the linear synchronization complexity bound Θ(N) with mathematical certitude."
  )
 elif slug=='relational-query-optimization':
  return (
   "In relational database query processing and physical execution theory, the tuple operation count T(N) = k_join · N + T_0 = 2.0000·N + 0.0000 operations across relation cardinality N is an exact algorithmic invariant for dual-phase in-memory Hash Join under uniform key distributions. "
   "Unlike continuous physical instrumentation, there is no analog sensor noise, thermal drift, or calibration variance in counting discrete hash bucket insertions or tuple key comparisons. "
   "However, in physical enterprise database engines (PostgreSQL, MySQL InnoDB, Oracle, Microsoft SQL Server), wall-clock query latency and execution costs are heavily modulated by computer microarchitecture, storage hardware, and operating system dynamics: "
   "(1) Memory hierarchy and buffer pool hit ratios: in-memory hash join probes hit DRAM frames in ~50–100 ns, whereas if relation partitions exceed buffer pool capacity M, external Grace hash join forces multi-pass disk paging where NVMe SSD random block reads incur 10–50 µs (~500× slower) and mechanical disk seeks incur 5–10 ms (~100,000× slower); "
   "(2) Hash bucket collision chains and data skew: non-uniform attribute distributions or frequent duplicate values ('heavy hitters') produce long collision chains in hash buckets, degrading probe complexity from O(1) average to O(N) pathological worst-case; "
   "(3) CPU cache line invalidation and TLB pressure: traversing large in-memory hash tables exceeding the CPU L3 cache capacity (typically 16–64 MB) incurs constant cache line misses and Translation Lookaside Buffer page walks, mitigated in high-performance engines by cache-conscious vectorized radix hash joins; and "
   "(4) Cardinality estimation error propagation: inaccurate system catalog histograms or violated attribute value independence (AVI) assumptions propagate errors exponentially across multi-join trees, causing optimizers to select disastrous physical join orders. "
   "Ordinary least-squares linear regression of observed tuple operations against relation cardinality N across instances from N = 1000 to N = 7000 tuples yields an empirical scaling multiplier k_join = 2.0000 comparisons/tuple and baseline intercept T_0 = 0.0000 operations with zero residual variance (R² = 1.00000), verifying the linear hash join complexity bound Θ(N) with mathematical certitude."
  )
 return ""

def graph(c,rows,f):
 left,right,top,bottom=68,610,28,280
 xs=[r['x']*c['xScale'] for r in rows];ys=[r['y']*c['yScale'] for r in rows]
 xmin=min(xs);xmax=max(xs);ymin=min(ys);ymax=max(ys)
 dx=(xmax-xmin) or 1;dy=(ymax-ymin) or 1
 xmin-=dx*.12;xmax+=dx*.12;ymin-=dy*.15;ymax+=dy*.15
 px=lambda x:left+(x-xmin)/(xmax-xmin)*(right-left)
 py=lambda y:bottom-(y-ymin)/(ymax-ymin)*(bottom-top)
 out=[]
 for i in range(5):
  x=xmin+i*(xmax-xmin)/4;y=ymin+i*(ymax-ymin)/4
  out.append(f'<line x1="{left}" y1="{py(y):.1f}" x2="{right}" y2="{py(y):.1f}" stroke="#dbe5eb"/>')
  out.append(f'<text x="{left-9}" y="{py(y)+4:.1f}" text-anchor="end" font-size="10" fill="#5a7687">{fmt(y,2)}</text>')
  out.append(f'<text x="{px(x):.1f}" y="300" text-anchor="middle" font-size="10" fill="#5a7687">{fmt(x,2)}</text>')
 out.append(f'<path d="M{left} {top}V{bottom}H{right}" stroke="#8ba5b5" fill="none"/>')
 out.append(f'<text x="335" y="332" text-anchor="middle" fill="#2b546b" font-size="12">{E(c["xAxis"])}</text>')
 out.append(f'<text transform="translate(15 160) rotate(-90)" text-anchor="middle" fill="#2b546b" font-size="12">{E(c["yAxis"])}</text>')
 pts=[f"{px(xmin+i*(xmax-xmin)/100):.1f},{py((f['m']*(xmin+i*(xmax-xmin)/100)/c['xScale']+f['b'])*c['yScale']):.1f}" for i in range(101)]
 out.append(f'<polyline points="{" ".join(pts)}" stroke="#1e3e52" stroke-width="2" fill="none"/>')
 for r in rows:
  out.append(f'<circle cx="{px(r["x"]*c["xScale"]):.1f}" cy="{py(r["y"]*c["yScale"]):.1f}" r="4.8" fill="#c05621"><title>n = {r["input"]}</title></circle>')
 return f'<svg viewBox="0 0 650 340" role="img" aria-label="Asymptotic regression plot of key comparisons against logarithmic entropy">{"".join(out)}</svg>'

def theory(c):
 out=[
  '<section class="theory-section">',
  f'<h2>Theoretical Foundations of {E(c["shortTitle"])} and Computational Complexity</h2>',
  f'<p class="intro">{E(c["intro"])}</p>',
  '<div class="theory-grid">'
 ]
 for i,t in enumerate(c['topics'],1):
  out.append(f'<article class="theory-card"><div class="theory-head"><span class="eyebrow">TOPIC {str(i).zfill(2)} · FORMAL ANALYSIS</span><h3>{E(t["question"])}</h3></div><div class="theory-body"><p>{E(t["answer"]).replace(chr(10), "<br><br>")}</p></div></article>')
 out.append('</div></section>')
 return "".join(out)

def method(c):
 return '<div class="method-steps">'+''.join(f'<article class="method-step"><div class="step-num">{str(i).zfill(2)}</div><div><h3>{E(s["title"])}</h3><p>{E(s["text"])}</p></div></article>' for i,s in enumerate(c['procedure'],1))+'</div>'

def workbench(c):
 sim_buttons=''.join(
  f'<button id="simMode{m["id"].capitalize()}" class="sim-mode-btn{" active" if i==0 else ""}" data-sim="{m["id"]}" type="button" role="tab" aria-selected="{"true" if i==0 else "false"}"><span class="sim-icon">{m["icon"]}</span> {E(m["label"])}</button>'
  for i,m in enumerate(c.get('simModes', [{'id':'bench','icon':'🔬','label':'1. Algorithm Bench'},{'id':'compare','icon':'⚖️','label':'2. Complexity Comparison'},{'id':'sandbox','icon':'⚛️','label':'3. Dynamic Sandbox'}]))
 )
 return f'''<section aria-label="Interactive workbench"><div class="section-top"><div><div class="eyebrow">COMPUTE · BENCHMARK · ANALYSE</div><h2>Your virtual algorithm laboratory.</h2></div><button id="resetApparatus" class="text-button">Reset benchmark</button></div><div class="new-workbench"><div class="new-visual"><div class="visual-top"><div class="sim-mode-switcher" role="tablist" aria-label="Simulation Views">{sim_buttons}</div><button id="pauseMotion" class="dark-button" hidden>Pause motion</button></div><svg id="apparatusDiagram" viewBox="0 0 720 320" role="img" aria-label="Interactive virtual array and comparator for {E(c['shortTitle'])}"></svg><div class="new-meter"><div><small>{E(c['rawLabel'].upper())}</small><strong id="readingValue">—</strong></div><div><small>EXECUTION STATUS</small><p id="liveState" style="font-size:11px;margin:7px 0">Ready to execute {E(c['shortInput'])} benchmark.</p></div></div></div><div class="new-controls"><label for="independent">{E(c['inputLabel'])}</label><output id="independentOut">{c['initial']} {E(c['inputUnit'])}</output><input id="independent" type="range" min="{c['min']}" max="{c['max']}" step="{c['step']}" value="{c['initial']}"><label for="independentNumber">Set {E(c['shortInput'])} ({E(c['inputUnit'])})</label><input id="independentNumber" type="number" min="{c['min']}" max="{c['max']}" step="{c['step']}" value="{c['initial']}"><div class="lab-control-meta">{E(c['settings'][0])}</div><button id="measure" class="primary full">{E(c['measureLabel'])}</button><button id="recordReading" class="secondary full" disabled>＋ Record observation</button><p id="trialStatus" class="trial-status" role="status">Adjust {E(c['shortInput'])} n, then execute benchmark.</p></div></div><p class="data-notice">Operation counts are generated deterministically by the exact algorithmic execution model. Modern hardware benchmarks additionally reflect cache line prefetching and branch misprediction penalties.</p><details class="model-note"><summary>Algorithmic assumptions and limits</summary><p>{E(c['limitations'])} {E(c['modelExtra'])}</p></details></section><section id="apparatus" class="lab-section"><h2>Computational tools & environment.</h2><div class="apparatus-list">{''.join('<article class="apparatus-item"><h3>'+E(a['name'])+'</h3><p>'+E(a['purpose'])+'</p></article>' for a in c['apparatus'])}</div></section><section id="method" class="lab-section"><div class="eyebrow">FOLLOW THE METHOD</div><h2>A reason behind every step.</h2><p class="intro">{E(c['aim'])} Suggested independent settings: {", ".join(map(str,c['samples']))} {E(c['inputUnit'])}.</p>{method(c)}</section><section id="results" class="lab-section"><div class="section-top"><div><div class="eyebrow">YOUR NOTEBOOK · <span id="notebookCount">0</span> OBSERVATIONS</div><h2>Turn measurements into asymptotic insight.</h2></div><a class="text-button" href="/computer-science/{c['slug']}/report/">See a complete example report ↗</a></div><div class="lab-result-grid"><div class="chart-card"><svg id="labPlot" viewBox="0 0 650 340" role="img" aria-label="Measured observations and fitted asymptotic graph"></svg><p>Points are your recorded benchmark observations. The regression line validates {E(c['shortTitle'])} complexity scaling.</p></div><div class="fit-card lab-fit"><span class="eyebrow">LINEAR ASYMPTOTIC FIT · y = mx + b</span><div id="fitSummary"></div><div class="report-equation">{E(c['fitEquation'])}</div></div></div><div class="table-card"><table><thead><tr><th>#</th><th>{E(c['inputLabel'])} ({E(c['inputUnit'])})</th><th>{E(c['rawLabel'])} ({E(c['rawUnit'])})</th><th>{E(c['xAxis'])}</th><th>{E(c['yAxis'])}</th><th>Remove</th></tr></thead><tbody id="readingRows"></tbody></table><p id="emptyReadings">No readings yet. Execute a {E(c['shortInput'])} benchmark and record it.</p></div><div class="lab-reading-actions"><button id="downloadReadings" class="secondary" disabled>↓ Export CSV</button><button id="clearReadings" class="secondary" disabled>Clear notebook</button></div><div class="source-box"><h3>Calculate it yourself.</h3><label for="studentEstimate">Your estimate of {E(c['target'])} ({E(c['resultUnit'])})</label> <input id="studentEstimate" type="number" step="any" min="0" style="max-width:140px"><button id="checkEstimate" class="secondary" style="margin-left:10px">Check calculation</button><p id="estimateFeedback" role="status"></p></div></section><section id="check" class="lab-section lab-questions"><div class="eyebrow">CHECK YOUR UNDERSTANDING</div><h2>Explain what the operation counts mean.</h2>{''.join('<article class="quiz-card"><h3>'+E(q['question'])+'</h3><div class="quiz-choices">'+''.join('<button class="quiz-option" data-quiz="'+str(i)+'" data-choice="'+str(j)+'">'+E(a)+'</button>' for j,a in enumerate(q['options']))+'</div><p id="quizFeedback'+str(i)+'" class="quiz-feedback" role="status"></p></article>' for i,q in enumerate(c['quiz']))}</section>'''

def report_narrative(c,rows,f,value,percent,reference):
 slug=c['slug']
 if slug=='search-algorithms-complexity':
  abstract=(
   f"Seven benchmark trials were generated across input sizes n = {rows[0]['input']} to n = {rows[-1]['input']} {c['inputUnit']}. "
   f"An ordinary least-squares regression of worst-case key comparisons against logarithmic entropy log₂(n) yielded an empirical complexity multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the theoretical divide-and-conquer bound "
   f"(difference = {percent:.4f}%). The results empirically prove that Binary Search exhibits optimal Θ(log₂ n) asymptotic scaling, outperforming "
   f"linear search by a factor of over 315× at n = {rows[-1]['input']}."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = log₂(n) represents input entropy in bits, "
   f"y = C represents discrete key comparisons, m represents the logarithmic scaling factor, and b represents baseline termination "
   f"comparison overhead. The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the theoretical divide-and-conquer recurrence T(n) = T(n/2) + O(1). "
   "The slope m = 1.0000 confirms that exactly one additional comparison is required each time the dataset size doubles, illustrating "
   "how logarithmic algorithms tame exponential data volume growth in modern computer systems."
  )
  conclusion=(
   "This laboratory investigation quantitatively demonstrated the asymptotic complexity of search algorithms. Through empirical "
   f"benchmarking across arrays ranging from {rows[0]['input']} to {rows[-1]['input']} elements, we verified that Binary Search achieves "
   f"an optimal logarithmic scaling gradient of k_search = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, matching "
   "the theoretical bound with zero residual error. The experiment highlights why divide-and-conquer is a foundational paradigm of modern "
   "computational infrastructure."
  )
 elif slug=='quadratic-sorting-algorithms':
  abstract=(
   f"Seven benchmark trials were generated across input sizes n = {rows[0]['input']} to n = {rows[-1]['input']} elements "
   f"(permutation pair space x = n(n − 1) from {int(rows[0]['x'])} to {int(rows[-1]['x'])} pairs). An ordinary least-squares regression "
   f"of key comparisons C against permutation pair space yielded an empirical quadratic scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the combinatorial identity "
   f"C(n) = 1/2 n(n − 1) (difference = {percent:.4f}%). The empirical telemetry proves that while Bubble, Selection, and Insertion Sort "
   f"all share Θ(n²) worst-case comparison complexity, Selection Sort strictly minimizes memory bus write amplification to at most n − 1 "
   f"element swaps (2n − 2 writes), compared to Bubble Sort's up to n(n − 1)/2 swaps (~3× writes per swap), explaining why Selection Sort "
   "is preferred in Flash/EEPROM architectures."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n(n − 1) represents the total permutation pair space in pairs, "
   f"y = C represents discrete key comparisons, m represents the quadratic scaling coefficient a_quad, and b represents baseline comparison "
   f"overhead. The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the combinatorial pair summation C(n) = ∑_{i=1}^{n-1} (n − i) = n(n − 1)/2. "
   "The slope m = 0.5000 confirms that exactly half of the directed pair space is compared in an unordered array. Furthermore, the inversion "
   "analysis demonstrates why any algorithm relying strictly on adjacent element swaps requires Ω(n²) comparisons on average, as each adjacent "
   "swap can eliminate at most one Kendall-tau inversion from an initial expectation of n(n − 1)/4 inversions. Finally, the hardware telemetry "
   f"highlights the critical trade-off between comparisons and memory write amplification: Selection Sort achieves identical comparisons "
   f"to Bubble Sort while reducing physical memory writes by a factor of over 35× at n = {rows[-1]['input']}."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the asymptotic complexity and microarchitectural behavior of quadratic sorting "
   f"algorithms. Through systematic benchmarking across arrays from {rows[0]['input']} to {rows[-1]['input']} elements, we verified the "
   f"quadratic scaling multiplier a_quad = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, matching theoretical predictions "
   "with an ideal R² = 1.00000. The investigation established the theoretical necessity of non-adjacent partition and exchange primitives "
   "(such as Quicksort and Heapsort) to overcome the Ω(n²) barrier imposed by pairwise adjacent transpositions."
  )
 elif slug=='divide-conquer-sorting':
  abstract=(
   f"Seven benchmark trials were generated across input sizes n = {rows[0]['input']} to n = {rows[-1]['input']} elements "
   f"(recursive merge interval space x = n(log₂ n − 1) from {int(rows[0]['x'])} to {int(rows[-1]['x'])} intervals). "
   f"An ordinary least-squares regression of key comparisons C against recursive interval space yielded an empirical linear scaling multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the theoretical worst-case recurrence bound "
   f"C(n) = n log₂ n − n + 1 (difference = {percent:.4f}%). The empirical telemetry proves that while Merge Sort, Quick Sort, and Heap Sort "
   f"all achieve optimal Θ(n log n) comparison scaling, Merge Sort guarantees strictly stable O(n log n) comparisons at the cost of O(n) auxiliary heap space, "
   f"Quick Sort provides minimal cache footprint with O(log n) stack frames but degrades to O(n²) under deterministic worst-case pivot selection, "
   f"and Heap Sort achieves guaranteed O(n log n) worst-case time with strictly O(1) auxiliary space, making Introsort and Timsort the industry standard hybrid architectures."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n(log₂ n − 1) represents the cumulative recursive comparison interval space, "
   f"y = C represents discrete key comparisons, m represents the divide-and-conquer scaling factor k_merge, and b represents the base-case leaf offset "
   f"(theoretically b = 1). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the Master Theorem Case 2 solution of the divide-and-conquer recurrence "
   "T(n) = 2T(n/2) + Θ(n), yielding T(n) = Θ(n log₂ n). The regression slope m = 1.0000 confirms that the merge step requires at most n − 1 comparisons "
   "across each of the log₂ n recursive tree levels. Furthermore, comparison of the three algorithms illustrates the deep microarchitectural trade-offs: "
   "Merge Sort requires O(n) auxiliary memory bandwidth for the merge scratchpad but guarantees complete stability and sequential memory streaming. "
   "Quick Sort eliminates auxiliary array allocations by partitioning in place around a pivot, achieving superior CPU L1/L2 cache locality, but risks "
   "quadratic degradation if recursion trees become unbalanced. Heap Sort enforces an explicit binary heap invariant (A[parent] ≥ A[child]), guaranteeing "
   "O(n log n) bounds in strictly O(1) auxiliary space, but suffers from poor cache locality due to non-local child index hops (2i + 1, 2i + 2). "
   "This empirical synthesis explains why production runtimes combine these paradigms into hybrid engines such as Timsort and Introsort."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the asymptotic complexity, recurrence dynamics, and microarchitectural behavior of divide-and-conquer "
   f"sorting algorithms. Across benchmark array sizes from {rows[0]['input']} to {rows[-1]['input']} elements, we verified the recursive merge scaling "
   f"multiplier k_merge = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. The investigation established "
   "the fundamental information-theoretic lower bound Ω(n log n) for comparison sorts derived from decision tree leaf entropy (log₂(n!) ≈ n log₂ n − 1.44n) "
   "and demonstrated why hybrid algorithms that switch between divide-and-conquer and insertion sort at cache-friendly thresholds achieve optimal practical performance."
  )
 elif slug=='stack-adt-recursion':
  abstract=(
   f"Seven benchmark trials were generated across recursive call depths n = {rows[0]['input']} to n = {rows[-1]['input']} frames "
   f"(peak virtual thread stack allocation from {int(rows[0]['raw'])} bytes to {int(rows[-1]['raw'])} bytes, or {rows[-1]['raw']/1024:.2f} KiB). "
   f"An ordinary least-squares regression of peak stack memory M against recursion depth n yielded an empirical activation record frame size of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the standard System V AMD64 ABI specification "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that unoptimized linear recursion incurs strict O(n) auxiliary memory overhead, "
   f"consuming memory bus bandwidth and risking fatal Stack Overflow (SIGSEGV) exceptions once depth exceeds the operating system thread stack limit, "
   f"whereas Tail-Call Optimization (TCO) and explicit heap-allocated stacks eliminate unbounded hardware stack pointer growth."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the recursive call stack depth in frames, "
   f"y = M represents peak memory consumption in bytes, m represents the physical activation record frame size F_frame, and b represents "
   f"the initial runtime startup CRT stack overhead M_0 (theoretically M_0 = 128 bytes). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the hardware architecture of the thread call stack. Each function invocation "
   "executes the machine instruction CALL, pushing the 8-byte instruction return address onto the stack, followed by the function prologue "
   "(`push rbp; mov rbp, rsp; sub rsp, 48`), resulting in a constant 64-byte activation record per invocation level. The regression slope m = 64.0000 "
   "confirms that stack memory grows linearly at exactly 64 bytes per recursion depth. Furthermore, comparative analysis across execution paradigms "
   "reveals the crucial distinction between recursion classes: while linear recursion requires O(n) activation records, divide-and-conquer tree recursion "
   "bounds peak stack depth to O(log n) frames, and tail-recursive functions can be compiled via Tail-Call Optimization into constant-space O(1) iterative "
   "jumps (`jmp`), completely neutralizing stack overflow vulnerability. Finally, the grammar parser experiment demonstrates the essential role of the "
   "Stack ADT in compiling and evaluating nested syntax trees, maintaining LIFO state invariants across arbitrary context-free grammars."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the memory architecture, activation record mechanics, and asymptotic behavior of the Stack Abstract Data Type. "
   f"Through systematic benchmarking across recursion depths from {rows[0]['input']} to {rows[-1]['input']} frames, we verified the empirical frame size "
   f"F_frame = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal coefficient of determination R² = 1.00000. "
   "The investigation established the microarchitectural necessity of stack memory discipline, proving how unbounded recursion risks thread stack exhaustion "
   "and validating tail-call optimization and heap-backed data structures as vital engineering defenses in modern software runtimes."
  )
 elif slug=='queue-buffer-management':
  abstract=(
   f"Seven benchmark trials were generated across packet batch sizes n = {rows[0]['input']} to n = {rows[-1]['input']} packets "
   f"(cumulative memory bus transfer volume from {int(rows[0]['raw'])} bytes to {int(rows[-1]['raw'])} bytes, or {rows[-1]['raw']/1024:.2f} KiB). "
   f"An ordinary least-squares regression of buffer transfer volume V against packet count n yielded an empirical packet throughput volume of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the 64-byte cache line payload specification "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that circular ring buffers eliminate the catastrophic O(n) element-shifting penalty "
   f"of naive array queues, recycling memory in-place via modular indexing arithmetic ((index + 1) mod N) to sustain millions of streaming transactions "
   f"per second with strictly O(1) operational complexity and zero runtime heap reallocations."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the cumulative packet batch size in packets, "
   f"y = V represents memory bus throughput volume in bytes, m represents the unit packet payload size L_packet, and b represents "
   f"the ring buffer descriptor header overhead V_0 (theoretically V_0 = 256 bytes). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the queuing mechanics of circular ring buffers. By logically joining index N − 1 back "
   "to index 0 via modular arithmetic, the circular buffer prevents pointer drift and achieves strictly O(1) time complexity for both enqueue and dequeue "
   "operations. The regression slope m = 64.0000 confirms that exactly 64 bytes (one standard CPU cache line) are transferred per processed packet. "
   "Furthermore, comparative architectural analysis across queue implementations demonstrates why ring buffers dominate high-performance computing: "
   "naive array queues incur unacceptable O(n) memory copy overhead on every dequeue, and linked-list queues suffer from heap fragmentation and pointer-chasing "
   "cache misses. In contrast, circular ring buffers provide contiguous spatial locality, enabling hardware prefetchers to anticipate memory accesses. "
   "Finally, multi-core analysis establishes the critical importance of cache-line padding: segregating atomic head and tail pointers onto separate 64-byte "
   "cache lines prevents catastrophic false sharing, allowing concurrent producers and consumers to achieve peak bus throughput."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the memory architecture, modular pointer dynamics, and asymptotic throughput of the Queue Abstract Data Type. "
   f"Through systematic benchmarking across stream sizes from {rows[0]['input']} to {rows[-1]['input']} packets, we verified the unit payload transfer volume "
   f"L_packet = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural superiority of circular ring buffers for asynchronous producer-consumer data flow, proving how "
   "modular indexing, power-of-two bitwise masking, and cache-line padding form the foundational infrastructure of modern operating system kernels and high-throughput networking stacks."
  )
 elif slug=='linked-list-architectures':
  abstract=(
   f"Seven benchmark trials were generated across dynamic linked list lengths n = {rows[0]['input']} to n = {rows[-1]['input']} nodes "
   f"(peak dynamic heap memory footprint from {int(rows[0]['raw'])} bytes to {int(rows[-1]['raw'])} bytes, or {rows[-1]['raw']/1024:.2f} KiB). "
   f"An ordinary least-squares regression of heap memory consumption M against list length n yielded an empirical node allocation size of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the 64-bit ABI doubly linked node specification "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that while doubly linked lists achieve optimal O(1) splice and deletion once a node pointer is held, "
   f"they impose a 300% pointer overhead (24 bytes of pointers and alignment padding per 8 bytes of data) and suffer catastrophic pointer-chasing cache misses during traversal, "
   f"demonstrating why modern high-performance systems utilize contiguous vectors or unrolled chunked lists (B-trees, unrolled linked lists) for cache-resident data pipelines."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the list length in nodes, "
   f"y = M represents total dynamic heap memory in bytes, m represents the individual node allocation footprint S_node, and b represents "
   f"the dual sentinel overhead M_0 (theoretically M_0 = 64 bytes). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the heap memory model of doubly linked list architectures. Each dynamically allocated node "
   "comprises an 8-byte 64-bit data value, an 8-byte forward pointer (next), an 8-byte backward pointer (prev), and 8 bytes of internal padding to maintain "
   "the mandatory 16-byte alignment required by standard glibc/ptmalloc allocators, totaling exactly 32 bytes per node. The regression slope m = 32.0000 "
   "confirms that heap memory expands linearly at exactly 32 bytes per node. Furthermore, microarchitectural analysis reveals the profound trade-offs "
   "between pointer structures and contiguous memory: while doubly linked lists allow O(1) node insertion and deletion without shifting elements, "
   "random traversal across non-contiguous heap pointers incurs high cache miss penalties because modern superscalar CPUs cannot prefetch non-linear memory strides. "
   "In contrast, contiguous vectors pack 8 values into a single 64-byte L1 cache line, streaming data at DRAM channel bandwidth (~50 GB/s). "
   "Finally, the sentinel sandbox demonstrates that integrating permanent dummy head and tail sentinel nodes eliminates boundary condition null checks "
   "(`head == NULL` and `tail == NULL`), eradicating conditional branch mispredictions during high-frequency list splice operations."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the memory footprint, pointer architecture, and microarchitectural behavior of Linked List Architectures. "
   f"Through systematic benchmarking across list sizes from {rows[0]['input']} to {rows[-1]['input']} nodes, we verified the empirical node footprint "
   f"S_node = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural trade-offs of pointer-based data structures, proving how pointer overhead and cache locality govern "
   "real-world computational throughput, and demonstrating why unrolled lists and sentinel-bounded doubly linked lists remain essential components of operating system schedulers and memory managers."
  )
 elif slug=='binary-search-trees':
  abstract=(
   f"Seven benchmark trials were generated across key dataset sizes n = {rows[0]['input']} to n = {rows[-1]['input']} keys "
   f"(logarithmic entropy x = log₂(n) from {rows[0]['x']:.1f} to {rows[-1]['x']:.1f} bits, tree height h from {rows[0]['raw']} to {rows[-1]['raw']} levels). "
   f"An ordinary least-squares regression of tree height h against logarithmic entropy log₂(n) yielded an empirical height scaling factor of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the theoretical complete binary tree bound "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that balanced binary search trees strictly constrain search path depth to optimal Θ(log₂ n) scaling, "
   f"outperforming degenerate unaugmented trees by a factor of over 315× at n = {rows[-1]['input']} keys (where degenerate height explodes to h = {rows[-1]['input']} levels), "
   f"and validating self-balancing rotation algorithms (AVL and Red-Black trees) as essential computational defenses against catastrophic worst-case degradation."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = log₂(n) represents key entropy in bits, "
   f"y = h represents tree height in levels, m represents the height scaling factor alpha, and b represents the baseline leaf level offset "
   f"(theoretically b = 1.0000 level). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the combinatorial capacity theorem for binary trees. Because each node has at most two children, "
   "a binary tree of height h can accommodate at most 2^h − 1 nodes. Inverting this geometric relationship yields the fundamental lower bound on tree height: "
   "h ≥ ⌈log₂(n + 1)⌉ = ⌊log₂ n⌋ + 1. The regression slope m = 1.0000 confirms that tree height increases by exactly 1 level each time dataset size doubles, "
   "mirroring the 1-bit entropy halving of Binary Search. Furthermore, topological comparison across insertion sequence regimes illustrates the vital "
   "importance of balance invariants: while randomly constructed binary search trees achieve an acceptable average search depth E[D(n)] ≈ 1.386 log₂ n, "
   "pathological monotonic insertion sequences (such as sorted datasets) cause unaugmented trees to collapse into degenerate singly-linked lists of height h = n. "
   "Under such degeneracy, search performance degrades catastrophically from O(log n) to O(n), and cumulative construction cost explodes to quadratic O(n²). "
   "Finally, the rotation sandbox demonstrates that local single (LL, RR) and double (LR, RL) tree rotations restore balance factor equilibrium (|BF| ≤ 1) in strictly "
   "O(1) time with 3 to 5 pointer updates, guaranteeing worst-case O(log n) bounds without whole-tree reconstruction."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the tree height dynamics, search path geometry, and balancing mechanics of Binary Search Trees. "
   f"Through systematic benchmarking across datasets from {rows[0]['input']} to {rows[-1]['input']} keys, we verified the empirical height scaling factor "
   f"alpha = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal coefficient of determination R² = 1.00000. "
   "The investigation established the microarchitectural necessity of self-balancing tree architectures, proving how AVL and Red-Black tree invariants "
   "protect systems from O(n) worst-case collapse, and demonstrating why multi-way B-trees remain the foundational storage architecture for high-fanout disk and cache-resident database engines."
  )
 elif slug=='binary-heaps-priority-queues':
  abstract=(
   f"Seven benchmark trials were generated across array buffer sizes n = {rows[0]['input']} to n = {rows[-1]['input']} keys "
   f"(cumulative sift interval space x = n − log₂(n) from {rows[0]['x']:.1f} to {rows[-1]['x']:.1f} intervals, heapify comparisons C from {rows[0]['raw']} to {rows[-1]['raw']} comparisons). "
   f"An ordinary least-squares regression of key comparisons C against cumulative sift space yielded an empirical heapify scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with Floyd's bottom-up linear construction bound "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that Floyd's bottom-up heapification achieves strict linear O(n) complexity, "
   f"delivering a 6-fold reduction in comparisons over naive repeated insertion (which consumes n log₂ n = {int(rows[-1]['input'] * math.log2(rows[-1]['input']))} comparisons at n = {rows[-1]['input']}), "
   f"while operating completely in-place within a contiguous array buffer with zero auxiliary pointer memory overhead."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n − log₂(n) represents the cumulative sift interval space in intervals, "
   f"y = C represents discrete key comparisons, m represents the heapify comparison scaling factor k_heap, and b represents baseline comparison offset "
   f"(theoretically b = 0.0000 comparisons). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations perfectly align with the geometric summation theorem governing Floyd's bottom-up heap construction. "
   "Because ⌈n/2⌉ nodes reside at height 0 (leaves) requiring 0 sifts, ⌈n/4⌉ nodes reside at height 1 requiring at most 1 sift, and in general at most ⌈n/2^{h+1}⌉ "
   "nodes reside at height h requiring at most h sifts, the total sifting work is bounded by (n/2) ∑_{h=0}^∞ (h / 2^h) = (n/2) × 2 = n. "
   "Accounting for exactly 2 comparisons per level (1 child-child comparison and 1 parent-child comparison), the exact comparison count is C(n) = 2(n − log₂ n). "
   "The regression slope m = 2.0000 confirms this linear relationship with zero residual variance. Furthermore, comparative analysis across priority queue "
   "architectures reveals crucial engineering trade-offs: naive unsorted arrays allow O(1) insertion but suffer disastrous O(n) extraction scans, sorted arrays "
   "permit O(1) extraction but require O(n) element shifting on insertion, and binary heaps achieve balanced O(log n) operations for both insertion and extraction "
   "with zero pointer overhead. Finally, the sandbox demonstration illustrates how 4-way heaps optimize modern microarchitectures by cutting tree height in half "
   "and aligning all four sibling nodes within a single 64-byte CPU cache line."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the comparison complexity, pointerless array mapping, and asymptotic scaling of Binary Heaps and Priority Queues. "
   f"Through systematic benchmarking across array sizes from {rows[0]['input']} to {rows[-1]['input']} keys, we verified the empirical heapify scaling factor "
   f"k_heap = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural superiority of complete binary trees for in-place priority scheduling, proving how Floyd's bottom-up algorithm "
   "attains linear O(n) construction and demonstrating why binary and d-ary heaps form the core engine of discrete-event simulators, operating system process schedulers, and Heapsort."
  )
 elif slug=='hash-tables-collision-resolution':
  abstract=(
   f"Seven benchmark trials were generated across key dataset sizes n = {rows[0]['input']} to n = {rows[-1]['input']} keys "
   f"in a fixed 1000-slot hash table (load factors α from {float(rows[0]['input'])/1000:.2f} to {float(rows[-1]['input'])/1000:.2f}, "
   f"transformed load coordinate x = 1 / (1 − α) from {rows[0]['x']:.4f} to {rows[-1]['x']:.4f}, expected unsuccessful search probe lengths E[P] from {rows[0]['raw']:.4f} to {rows[-1]['raw']:.4f} probes). "
   f"An ordinary least-squares regression of probe depths against the transformed load coordinate yielded an empirical probe scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with Knuth's uniform hashing theorem "
   f"(difference = {percent:.4f}%). The empirical telemetry confirms that Double Hashing completely eliminates primary and secondary clustering, "
   f"achieving the optimal theoretical probe bound E[P] = 1 / (1 − α) and outperforming Linear Probing by a factor of 5× at high load factors (α = 0.90)."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = 1 / (1 − α) represents the transformed load factor coordinate, "
   f"y = E[P] represents the expected number of memory probes in an unsuccessful search, m represents the probe scaling factor k_hash, and b represents "
   f"the baseline probe offset (theoretically b = 0.0000 probes). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Knuth's asymptotic probe bounds in open-address hash tables. "
   "As key count n increases from 100 to 900 keys (load factor α from 0.10 to 0.90), the raw probe length exhibits a dramatic non-linear acceleration, "
   "rising from 1.1111 probes at α = 0.10 to 10.0000 probes at α = 0.90. Plotting probe depths against the linearized coordinate x = 1 / (1 − α) transforms "
   "this asymptotic divergence into a straight line with slope m = 1.0000 and R² = 1.00000, confirming that the number of unsuccessful search probes follows "
   "a geometric distribution with success parameter p = 1 − α. Comparative analysis across collision resolution strategies reveals profound architectural trade-offs: "
   "Separate Chaining tolerates load factors α > 1.0 and degrades linearly (E[P] = α), but incurs severe CPU cache misses due to pointer chasing across fragmented heap memory. "
   "Linear Probing maximizes CPU L1 spatial cache locality by scanning adjacent array slots, but suffers from catastrophic Primary Clustering where contiguous runs act as "
   "gravitational attractors, squaring the probe penalty to E[P] ≈ 0.5(1 + 1/(1-α)²). Double Hashing eliminates both primary and secondary clustering by varying the probe stride "
   "as a function of the key itself (h₂(k) coprime to m), achieving the ideal theoretical probe bound 1 / (1 − α). Finally, the investigation demonstrates why modern systems "
   "libraries (such as Google Abseil Swiss Tables and Rust hashbrown) pair open addressing with 1-byte control arrays and SIMD vector instructions to inspect 16 slots simultaneously in L1 cache."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the collision resolution mechanics, probe distributions, and asymptotic load scaling of Hash Tables. "
   f"Through systematic benchmarking across load factors from α = {float(rows[0]['input'])/1000:.2f} to α = {float(rows[-1]['input'])/1000:.2f}, we verified the empirical probe scaling factor "
   f"k_hash = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural trade-offs between cache-friendly contiguous arrays and pointer-based chaining, proving why Double Hashing, "
   "Robin Hood equalized probing, and SIMD control-byte Swiss Tables form the core dictionary implementation of modern operating systems, database indexes, and high-throughput compilers."
  )
 elif slug=='graph-traversal-shortest-paths':
  abstract=(
   f"Seven benchmark trials were generated across network sizes |V| = {rows[0]['input']} to |V| = {rows[-1]['input']} vertices "
   f"in a connected network with average out-degree d = 4 edges/vertex (|E| = {4*rows[0]['input']} to |E| = {4*rows[-1]['input']} edges, "
   f"traversal operations T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of traversal operations against vertex count yielded an empirical complexity scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the linear Adjacency List bound "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that Breadth-First Search (BFS) and Depth-First Search (DFS) achieve optimal "
   f"linear O(|V| + |E|) complexity on Adjacency Lists, outperforming quadratic Adjacency Matrix representations by over 200× at |V| = 1000 vertices."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = |V| represents the graph vertex count in vertices, "
   f"y = T represents total elementary traversal operations, m represents the complexity scaling factor k_graph, and b represents "
   f"the baseline operation offset (theoretically b = 0.0000 operations). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of the fundamental linear scaling theorem governing graph traversals. "
   "In an Adjacency List representation, every vertex is discovered and enqueued exactly once (|V| operations), and every incident directed edge is traversed "
   "exactly once during neighbor exploration (|E| = 4|V| operations). The total operation count T(|V|) = |V| + 4|V| = 5|V| scales in strict linear proportion "
   "to network size. The regression slope m = 5.0000 confirms this invariant with zero residual variance (R² = 1.00000). Comparative analysis across graph "
   "representations highlights critical systems trade-offs: an Adjacency Matrix requires Θ(|V|²) memory (1 million entries at |V| = 1000) and forces neighbor "
   "iterations to scan all |V| columns (taking 1,000,000 operations), whereas an Adjacency List consumes only Θ(|V| + |E|) memory (5,000 elements) and completes "
   "traversal in 5,000 operations—a 200-fold performance advantage. Furthermore, the Dijkstra sandbox demonstrates how greedy edge relaxation computes Single-Source "
   "Shortest Paths in O((|V| + |E|) log |V|) time using a Min-Heap, illustrating why non-negative edge weights are mathematically required to preserve the greedy choice property. "
   "Finally, the investigation explores modern Compressed Sparse Row (CSR) formats, showing how contiguous array packing eliminates pointer chasing and maximizes CPU L1 cache utilization."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the memory representations, traversal dynamics, and asymptotic scaling of Graph Algorithms. "
   f"Through systematic benchmarking across networks from |V| = {rows[0]['input']} to {rows[-1]['input']} vertices, we verified the empirical traversal scaling factor "
   f"k_graph = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural superiority of sparse adjacency structures over dense matrices, proving why Adjacency Lists, Compressed Sparse Row (CSR), "
   "and Min-Heap priority queues form the core computational engine of network routing protocols, social network graphs, and large-scale distributed analytics."
  )
 elif slug=='dynamic-programming-memoization':
  abstract=(
   f"Seven benchmark trials were generated across item scales n = {rows[0]['input']} to n = {rows[-1]['input']} items "
   f"for a 0/1 Knapsack problem with fixed capacity budget W = 100 weight units (state evaluations T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of tabulation state evaluations against item count yielded an empirical complexity scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the theoretical pseudo-polynomial bound "
   f"(difference = {percent:.4f}%). The empirical telemetry proves that Bottom-Up Tabulation eliminates exponential recursion trees (reducing Θ(2^n) to Θ(n·W)), "
   f"achieving optimal sequential L1 cache throughput and delivering over 10^40-fold speedups over naive recursion at n = 150 items."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the problem item count in items, "
   f"y = T represents total elementary tabulation state evaluations, m represents the complexity scaling factor k_dp, and b represents "
   f"the baseline evaluation offset (theoretically T_0 = 0.0000 states). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Bellman's Dynamic Programming paradigm and pseudo-polynomial state complexity. "
   "In Bottom-Up Tabulation of the 0/1 Knapsack Problem with fixed capacity W = 100, each cell DP[i][w] in the (n + 1) × (W + 1) matrix represents an independent subproblem state. "
   "Because each cell evaluates the Bellman optimality recurrence DP[i][w] = max(DP[i-1][w], DP[i-1][w - w_i] + v_i) in strict O(1) arithmetic operations, the total number of evaluations "
   "T(n) = W · n = 100·n scales in exact linear proportion to the number of items. The regression slope m = 100.0000 confirms this invariant with zero residual variance (R² = 1.00000). "
   "Comparative analysis across computational models reveals profound architectural insights: Naive Recursion suffers from catastrophic exponential explosion Θ(2^n), "
   "requiring 2¹⁵⁰ ≈ 1.4 × 10⁴⁵ operations at n = 150 items—an intractable computation exceeding the age of the universe. Top-Down Memoization prunes this tree to at most n·W reachable states, "
   "but incurs significant call stack allocation (48 bytes per AMD64 frame) and pointer lookup overhead. Bottom-Up Tabulation completely eliminates stack frames, while enabling perfect "
   "sequential row-major L1 cache streaming (fetching 8 cells per 64-byte cache line). Furthermore, the investigation demonstrates how 1D reverse scanning (iterating w from W down to w_i) "
   "compresses the spatial memory footprint from Θ(n·W) down to Θ(W), keeping the entire working set resident in CPU L2 cache while strictly preserving the 0/1 non-duplication invariant. "
   "Finally, Backtracking Reconstruction proves that the exact optimal subset of items can be recovered from the 2D table in O(n) linear time, cementing Dynamic Programming as the premier "
   "optimization architecture for production resource scheduling, cryptography, and compiler instruction selection."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the recurrence relations, state space dynamics, and memory hierarchy trade-offs of Dynamic Programming. "
   f"Through systematic benchmarking across item counts from n = {rows[0]['input']} to {rows[-1]['input']} items, we verified the empirical state scaling factor "
   f"k_dp = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural superiority of Bottom-Up Tabulation and 1D reverse-scanned rolling buffers over naive exponential recursion and recursive memoization, "
   "proving why Dynamic Programming serves as a foundational pillar of modern computer science, computational genomics, and algorithmic operations research."
  )
 elif slug=='greedy-minimum-spanning-trees':
  abstract=(
   f"Seven benchmark trials were generated across network sizes |V| = {rows[0]['input']} to |V| = {rows[-1]['input']} vertices "
   f"with candidate edge pool |E| = {4*rows[0]['input']} to |E| = {4*rows[-1]['input']} edges (|E| = 4|V|, DSU queries Q from {rows[0]['raw']} to {rows[-1]['raw']} lookups). "
   f"An ordinary least-squares regression of disjoint set queries against vertex count yielded an empirical complexity scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}, demonstrating exact agreement with the theoretical DSU query bound "
   f"(difference = {percent:.4f}%). The empirical telemetry confirms that Kruskal's algorithm with Path Compression and Union by Rank evaluates "
   f"component connectivity in near-constant amortized time O(α(|V|)), constructing optimal spanning trees containing exactly |V| - 1 edges while strictly enforcing the Cut Property."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = |V| represents the network vertex count in vertices, "
   f"y = Q represents total disjoint set representative lookups, m represents the query scaling factor k_mst, and b represents "
   f"the baseline query offset (theoretically Q_0 = 0.0000 lookups). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of the greedy Minimum Spanning Tree paradigm and Disjoint Set Union mechanics. "
   "In Kruskal's algorithm on an undirected graph G = (V, E) with |E| = 4|V| candidate edges, every candidate edge (u, v) is examined in ascending weight order. "
   "To test whether edge (u, v) connects disjoint subtrees or forms an illegal cycle, the algorithm invokes Find(u) and Find(v), requiring exactly 2 queries per edge. "
   "The total query count Q(|V|) = 2|E| = 8|V| scales in strict linear proportion to vertex count. The regression slope m = 8.0000 confirms this invariant with zero residual variance (R² = 1.00000). "
   "Furthermore, across all trials, the resulting spanning tree contains exactly |V| - 1 edges, confirming Cayley's fundamental tree theorem. "
   "Comparative analysis across MST paradigms elucidates critical architectural trade-offs: Kruskal's algorithm is edge-centric and excels on sparse networks where |E| << |V|², "
   "as sorting |E| edges takes O(|E| log |V|) and DSU queries execute in near-constant inverse Ackermann time O(α(|V|)). Prim's algorithm is vertex-centric, utilizing a priority queue "
   "to grow a single cut component in O((|V| + |E|) log |V|) time (or O(|E| + |V| log |V|) with Fibonacci heaps), proving superior on dense graphs where |E| ≈ |V|². "
   "Borůvka's algorithm provides an embarrassingly parallel formulation, executing in O(log |V|) contraction rounds ideal for distributed GPU clusters. "
   "Finally, the investigation proves why the Cut Property and Matroid Theory guarantee that greedy local choices yield the globally optimal minimum-weight infrastructure."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the greedy choice dynamics, Cut Property invariants, and asymptotic scaling of Minimum Spanning Tree algorithms. "
   f"Through systematic benchmarking across networks from |V| = {rows[0]['input']} to {rows[-1]['input']} vertices, we verified the empirical DSU query scaling factor "
   f"k_mst = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency of Disjoint Set Union with Path Compression and Union by Rank, proving why Kruskal's and Prim's algorithms "
   "form the algorithmic foundation of modern telecommunications routing, clustering in machine learning, and approximation schemes for NP-hard network design."
  )
 elif slug=='string-matching-automata':
  abstract=(
   f"Seven benchmark trials were generated across text stream lengths n = {rows[0]['input']} to n = {rows[-1]['input']} characters "
   f"with fixed query pattern length m = 20 characters (total comparisons C from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of character comparisons against text stream length yielded an empirical scanning slope of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} comparisons, "
   f"demonstrating exact agreement with the theoretical Knuth-Morris-Pratt complexity model C(n) = n + m (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that KMP eliminates text pointer backtracking entirely, advancing the stream pointer monotonically "
   f"while resolving character mismatches via the failure function π in amortized linear time O(n + m)."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the input text stream length in characters, "
   f"y = C represents total character comparison operations, m represents the scanning slope k_kmp, and b represents "
   f"the failure array preprocessing comparison overhead (theoretically C_0 = 20.0000 comparisons). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of the Knuth-Morris-Pratt automaton and asymptotic string processing complexity. "
   "In KMP text scanning with query pattern length m = 20, the text pointer i advances strictly from 0 to n - 1 without ever decrementing. "
   "Upon encountering a character mismatch between T[i] and P[j], the pattern pointer falls back to state j' = π[j - 1], preserving all previously matched substring prefixes. "
   "Because each character mismatch fallback decreases the pattern state j while i continues advancing, amortized analysis via the potential function Φ = j proves that "
   "the total number of character comparisons is strictly bounded by 2n. On uniform text streams, the empirical scanning slope m = 1.0000 confirms that exactly one comparison "
   "is executed per text character on average, while the intercept b = 20.0000 matches the exact preprocessing comparison cost of constructing the 20-element failure table π[0 .. 19]. "
   "The regression fit exhibits zero residual variance (R² = 1.00000). "
   "Comparative paradigm analysis reveals critical microarchitectural trade-offs across string matching architectures: Naive brute-force search suffers catastrophic Θ(n · m) "
   "worst-case degradation when processing self-similar prefixes, rewinding the text pointer and evicting CPU L1 data cache lines. In contrast, KMP guarantees strictly linear O(n + m) "
   "streaming performance with O(1) auxiliary working memory, making it ideal for unbuffered network sockets and Unix pipes. Boyer-Moore achieves sublinear O(n/m) average-case time "
   "on large alphabets by scanning right-to-left and jumping forward by up to m positions per bad-character mismatch. Rabin-Karp provides O(1) sliding window updates via polynomial rolling hashes, "
   "enabling seamless multi-pattern and 2D matrix matching. Aho-Corasick scales multi-pattern dictionary matching to wire speed by compiling pattern sets into trie automata with failure and output links. "
   "Finally, modern hardware implementations leverage SIMD vectorization (AVX-512 and ARM Neon) to compare 64 characters in parallel per clock cycle, demonstrating how hardware and algorithm co-design maximizes search throughput."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the failure function mechanics, state transition dynamics, and asymptotic linear scaling of string matching automata. "
   f"Through systematic benchmarking across text streams from n = {rows[0]['input']} to {rows[-1]['input']} characters, we verified the empirical text scan slope "
   f"k_kmp = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and failure table intercept C_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural superiority of non-backtracking automata, contrast heuristics, and vector extensions over naive quadratic scanning, "
   "proving why KMP, Boyer-Moore, Rabin-Karp, and Aho-Corasick form the foundational core of modern computational genomics, search engines, and network intrusion detection systems."
  )
 elif slug=='network-flow-max-cut':
  abstract=(
   f"Seven benchmark trials were generated across network scales |V| = {rows[0]['input']} to |V| = {rows[-1]['input']} vertices "
   f"with candidate edge pool |E| = {3*rows[0]['input']} to |E| = {3*rows[-1]['input']} edges (|E| = 3|V|, residual inspections T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of residual graph inspections against vertex count yielded an empirical scaling coefficient of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} inspections, "
   f"demonstrating exact agreement with the theoretical Edmonds-Karp augmentation bound (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that backward residual edges enable exact flow cancellation without violation of conservation laws, "
   f"and the resulting minimum cut capacity strictly equals total maximum flow, verifying the Max-Flow Min-Cut Theorem."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = |V| represents the network vertex count in vertices, "
   f"y = T represents total residual graph augmenting inspections, m represents the augmentation scaling slope k_flow, and b represents "
   f"the baseline evaluation offset (theoretically T_0 = 0.0000 inspections). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of the Edmonds-Karp network flow algorithm and the Max-Flow Min-Cut duality theorem. "
   "In a directed flow network G = (V, E) with capacity function c(u, v) and edge density |E| = 3|V|, the Edmonds-Karp solver iteratively executes Breadth-First Search "
   "to locate augmenting paths with minimum edge count in the residual graph G_f. Each BFS traversal inspects reachable vertices and admissible residual edges in O(|V| + |E|) time. "
   "Because backward residual edges carry reverse capacity c_f(v, u) = f(u, v), augmenting along backward edges cancels previous sub-optimal allocations, ensuring convergence "
   "to the global maximum flow |f*|. Across all benchmark network scales, total residual inspections scale as T(|V|) = 10.0000·|V|, confirming the linear scaling invariant with "
   "zero residual variance (R² = 1.00000). Upon flow saturation, a final BFS from source s identifies the reachable component S; the capacity of the cut (S, V \\ S) exactly equals "
   "the maximum flow |f*|, providing an empirical manifestation of Linear Programming Strong Duality. "
   "Comparative paradigm analysis elucidates key architectural trade-offs: generic Ford-Fulkerson can require pseudo-polynomial O(|E| · |f*|) iterations and may fail to terminate on irrational capacities; "
   "Edmonds-Karp guarantees strongly polynomial O(|V| · |E|²) time by monotonic shortest-path distance growth; Dinic's algorithm advances sink levels in a layered DAG to achieve O(|V|² · |E|) "
   "(and O(|E| √|V|) on bipartite matching networks); and Push-Relabel algorithms achieve O(|V|³) via local height discharges. "
   "Finally, the investigation highlights how maximum flow serves as a universal solver for bipartite matching, image segmentation via graph cuts, and network reliability."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified augmenting path dynamics, residual back-edge mechanics, and duality theorems in network flow optimization. "
   f"Through systematic benchmarking across networks from |V| = {rows[0]['input']} to {rows[-1]['input']} vertices, we verified the empirical residual inspection slope "
   f"k_flow = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural and theoretical superiority of BFS-driven augmentations and residual graph duality, "
   "proving why Max-Flow Min-Cut remains one of the foundational cornerstones of combinatorial optimization, computer vision, and network engineering."
  )
 elif slug=='trie-prefix-trees':
  abstract=(
   f"Seven benchmark trials were generated across prefix search key lengths L = {rows[0]['input']} to L = {rows[-1]['input']} characters "
   f"(total pointer dereferences T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of trie pointer dereferences against query key length yielded an empirical traversal slope of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} dereferences, "
   f"demonstrating exact agreement with the theoretical trie retrieval complexity model T(L) = L + 1 (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that trie lookup latency is strictly invariant to the total number of dictionary keys n, "
   f"scaling in direct linear proportion to key length L while supporting prefix autocompletion, wildcard searching, and longest prefix matching."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = L represents the search key length in characters, "
   f"y = T represents total pointer dereference operations, m represents the traversal slope k_trie, and b represents "
   f"the root sentinel node dereference overhead (theoretically T_0 = 1.0000 dereferences). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of the Trie prefix tree architecture and asymptotic retrieval complexity. "
   "In a standard multi-way trie over alphabet Σ, the search algorithm begins at the root sentinel node (consuming 1 initial pointer inspection) and sequentially dereferences "
   "the child pointer corresponding to each character in the query key of length L. Because each character transition advances down the trie hierarchy by exactly one level, "
   "the traversal executes exactly L child dereferences, yielding total memory operations T(L) = 1.0000·L + 1.0000. Across all benchmark key lengths from L = 4 to L = 48 characters, "
   "the regression slope m = 1.0000 and intercept b = 1.0000 confirm this invariant with zero residual variance (R² = 1.00000). Crucially, the total number of keys n stored in the "
   "dictionary has zero effect on lookup depth, distinguishing tries from comparison-based binary search trees which scale as O(L · log n). "
   "Comparative architectural analysis elucidates vital engineering trade-offs across prefix tree representations: Standard multi-way tries provide optimal O(L) lookup times "
   "but suffer extreme spatial memory inflation when allocating 256 child pointers per node (2,048 bytes) on sparse vocabularies. Compressed Radix Trees (Patricia Tries) solve this "
   "by eliminating unbranched single-child nodes, collapsing linear edge sequences into composite substring labels, guaranteeing at most 2n - 1 nodes for n keys. "
   "Ternary Search Trees (TST) combine the space efficiency of binary search trees with the prefix properties of tries, branching three ways (left, equal, right) to reduce memory "
   "to 3 pointers per node at the cost of O(L + log |Σ|) lookup latency. In telecommunications and IP networking, multi-stride radix tries execute Longest Prefix Matching (LPM) "
   "over 32-bit IPv4 and 128-bit IPv6 CIDR forwarding tables, enabling core internet routers to forward packets at line speeds exceeding 400 Gbps. "
   "Finally, modern in-memory database engines employ Adaptive Radix Trees (ART), which dynamically resize nodes between 4 compact types (Node4, Node16, Node48, Node256) and "
   "use SIMD instructions to deliver both cache-conscious memory density and branch-free retrieval throughput."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the node structure, path compression mechanisms, and asymptotic retrieval scaling of Trie and Radix prefix trees. "
   f"Through systematic benchmarking across query key lengths from L = {rows[0]['input']} to {rows[-1]['input']} characters, we verified the empirical retrieval slope "
   f"k_trie = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and sentinel intercept T_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural and algorithmic superiority of compressed radix trees and adaptive prefix tries over naive multi-way pointer arrays and comparison trees, "
   "proving why trie architectures serve as the backbone of modern IP routing, full-text search engines, lexical compilers, and high-performance key-value databases."
  )
 elif slug=='huffman-coding-compression':
  abstract=(
   f"Seven benchmark trials were generated across raw symbol stream lengths n = {rows[0]['input']} to n = {rows[-1]['input']} symbols "
   f"(uncompressed 8-bit ASCII size from {8*rows[0]['input']} bits to {8*rows[-1]['input']} bits; compressed bitstream B from {rows[0]['raw']} to {rows[-1]['raw']} bits). "
   f"An ordinary least-squares regression of compressed bitstream size against input symbol count yielded an empirical average code length of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and a canonical header intercept of {fmt(f['b'],c['resultDecimals'])} bits, "
   f"demonstrating exact agreement with David Huffman's optimal prefix coding model B(n) = 2.5·n + 64 (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that Huffman coding compresses redundant 8-bit ASCII streams by 68.75%, "
   f"approaching the theoretical Shannon source entropy limit H(X) = 2.4464 bits/symbol while guaranteeing instantaneous, ambiguity-free prefix decoding."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the input stream length in symbols, "
   f"y = B represents total compressed bitstream size in bits, m represents the average prefix code length L_bar, and b represents "
   f"the canonical codebook header table overhead B_0 (theoretically B_0 = 64.0000 bits). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of David Huffman's minimum-redundancy prefix coding algorithm and Shannon's Source Coding Theorem. "
   "For an information source over an 8-symbol vocabulary with probability distribution P = {0.35, 0.20, 0.15, 0.10, 0.08, 0.06, 0.04, 0.02}, the theoretical Shannon source entropy "
   "is H(X) = -∑ p_i log₂(p_i) = 2.4464 bits/symbol. The Min-Heap greedy tree construction iteratively merges the two lowest-probability subtrees, synthesizing an optimal full binary "
   "trie with codeword lengths l = [2, 2, 3, 3, 4, 4, 5, 5] bits. The resulting average code length L_bar = ∑ p_i · l_i = 2.5000 bits/symbol strictly satisfies Shannon's fundamental "
   "entropy bound: H(X) ≤ L_bar < H(X) + 1, with minimal redundancy R = L_bar - H(X) = 0.0536 bits/symbol due to integer bit constraints. The regression slope m = 2.5000 confirms "
   "that each additional input symbol consumes exactly 2.5000 bits on average, while the intercept b = 64.0000 bits exactly reflects the 64-bit canonical codebook header table. "
   "Across all trials, the regression exhibits zero residual variance (R² = 1.00000). "
   "Comparative analysis across compression paradigms illuminates fundamental algorithmic trade-offs: Fixed-width 8-bit ASCII requires 8n bits per stream, yielding zero compression. "
   "Run-Length Encoding (RLE) compresses repeating consecutive runs but expands non-repeating diverse text. Huffman coding operates optimally on stationary symbol statistics, "
   "guaranteeing instantaneous O(B) decoding via the Prefix Property without lookahead. Lempel-Ziv dictionary algorithms (LZ77/LZ78) capture multi-character string repetitions by emitting "
   "(distance, length) offset tokens. In industry-standard formats such as DEFLATE (used in Gzip, ZIP, and PNG), LZ77 and Huffman coding are cascaded: LZ77 eliminates string redundancies, "
   "and Huffman coding compresses the resulting literal and distance token alphabets. Finally, Arithmetic Coding eliminates the integer bit constraint of Huffman coding by mapping messages "
   "to fractional intervals, achieving compression closer to H(X) at the cost of higher CPU arithmetic overhead."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the greedy tree construction, Kraft-McMillan invariants, and asymptotic compression scaling of Huffman prefix coding. "
   f"Through systematic benchmarking across stream sizes from n = {rows[0]['input']} to {rows[-1]['input']} symbols, we verified the empirical average code length "
   f"L_bar = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and canonical header intercept B_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical optimality of Min-Heap tree synthesis, canonical codebook serializations, and table-driven bitstream decoders, "
   "proving why Huffman coding remains the universal entropy coding engine underpinning modern digital telecommunications, multimedia formats, and global internet data transmission."
  )
 elif slug=='computational-geometry-convex-hull':
  abstract=(
   f"Seven benchmark trials were generated across planar point cloud sizes n = {rows[0]['input']} to n = {rows[-1]['input']} points "
   f"(total orientation cross-product evaluations T from {rows[0]['raw']} to {rows[-1]['raw']} tests). "
   f"An ordinary least-squares regression of orientation tests against point count yielded an empirical scanning slope of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} tests, "
   f"demonstrating exact agreement with Ronald Graham's amortized scanning model T(n) = 2n (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that once sorted radially by polar angle in O(n log n) time, "
   f"Graham's stack-based perimeter traversal resolves all non-convex reflex vertices in strictly linear O(n) amortized time."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = n represents the planar point set size in points, "
   f"y = T represents total 2D cross-product orientation evaluations, m represents the scan test slope k_ccw, and b represents "
   f"the baseline evaluation offset (theoretically T_0 = 0.0000 tests). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Graham's Scan and planar convex hull complexity theory. "
   "In Graham's scan over a point set P ⊂ ℝ² with |P| = n points, the algorithm first selects the bottom-most extreme pivot point P_0 and sorts all remaining "
   "points radially in ascending polar angle order in O(n log n) time. During the perimeter scan, points are processed sequentially using the candidate hull stack. "
   "For each incoming point, the algorithm repeatedly evaluates the 2D cross-product orientation predicate Δ(p_prev, p_top, p_curr) = (x_top - x_prev)(y_curr - y_prev) - (y_top - y_prev)(x_curr - x_prev). "
   "A negative or zero determinant (Δ ≤ 0) indicates a clockwise right turn or collinear edge, necessitating that p_top be popped from the stack as an interior non-convex reflex vertex. "
   "Because each point is pushed onto the stack exactly once and can be popped at most once, the total number of orientation evaluations during the scan phase is strictly bounded "
   "by 2n tests. Across all benchmark trials from n = 50 to n = 5000 points, the empirical regression slope m = 2.0000 and intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "Comparative paradigm analysis elucidates vital engineering trade-offs across geometric hull architectures: Jarvis March (Gift Wrapping) executes in O(n · h) time, "
   "where h is the number of hull vertices; when h << log n, Jarvis March outperforms Graham Scan, but degrades to O(n²) when all points lie on the convex boundary. "
   "Quickhull achieves O(n log n) expected time via recursive bisection and interior point elimination, but suffers worst-case O(n²) degradation on circular arcs. "
   "Chan's algorithm unifies Graham Scan sub-hulls with Jarvis March wrapping to achieve the optimal output-sensitive bound O(n log h). "
   "Finally, numerical analysis emphasizes the critical necessity of exact geometric predicates: near-collinear point triplets cause floating-point sign-flips in IEEE 754 arithmetic, "
   "which are eliminated in production pipelines via Jonathan Shewchuk's adaptive precision floating-point expansions."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the orientation predicates, stack mechanics, and asymptotic scaling of planar Convex Hull algorithms. "
   f"Through systematic benchmarking across point sets from n = {rows[0]['input']} to {rows[-1]['input']} points, we verified the empirical scan test slope "
   f"k_ccw = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept T_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical optimality of Graham's Scan, Jarvis March, and adaptive precision orientation predicates, "
   "proving why convex hull algorithms form an indispensable foundation of modern physics engines, computer vision systems, geographic information systems, and computational geometry."
  )
 elif slug=='backtracking-n-queens-sat':
  abstract=(
   f"Seven benchmark trials were generated across chessboard dimensions / decision depths N = {rows[0]['input']} to N = {rows[-1]['input']} queens "
   f"(total bitwise constraint register operations T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of bitwise register evaluations against board dimension yielded an empirical scaling slope of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} operations, "
   f"demonstrating exact agreement with Rich Burroughs' bitmask backtracking invariant T(N) = 4N (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by mapping column and diagonal attack invariants into 64-bit integer registers, "
   f"each decision level executes in strictly 4 atomic bitwise ALU operations, pruning over 99.98% of the combinatorial state space."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = N represents the chessboard dimension / decision tree depth in queens, "
   f"y = T represents total bitwise constraint register operations, m represents the operational step slope k_bit, and b represents "
   f"the baseline evaluation offset (theoretically T_0 = 0.0000 operations). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Constraint Satisfaction Problem (CSP) theory, state space tree pruning, and boolean satisfiability architectures. "
   "In the N-Queens puzzle, an unrestricted placement of N queens across an N × N chessboard yields (N² choose N) states, while enforcing one queen per row reduces the search space to N^N. "
   "Permutation backtracking further restricts the domain to N! configurations by preventing column sharing. "
   "However, by incorporating diagonal conflict constraints—formalized as |r₁ - r₂| = |c₁ - c₂| and partitioned into left diagonals (r - c) and right diagonals (r + c)—backtracking prunes the state space tree with extreme efficacy. "
   "For an 8-Queens board, diagonal pruning eliminates over 99.98% of the search tree, inspecting only 2,057 nodes to discover all 92 distinct solutions. "
   "The microarchitectural implementation leverages Rich Burroughs' bitmask formulation, representing columns, left diagonals, and right diagonals as 64-bit machine registers. "
   "At each row level, the algorithm computes occupied columns in a single clock cycle (occupied = cols | diag_left | diag_right), inverts to isolate legal placements, "
   "extracts the lowest candidate bit using two's complement arithmetic (bit = available & -available), and propagates constraints to the subsequent row via bitwise shifts ((diag_left | bit) << 1 and (diag_right | bit) >> 1). "
   "Across all benchmark trials from N = 4 to N = 16 queens, the empirical regression slope m = 4.0000 operations/queen and intercept b = 0.0000 confirm this four-operation invariant with zero residual variance (R² = 1.00000). "
   "Comparative analysis across combinatorial search paradigms highlights critical architectural trade-offs: "
   "Naive permutation search runs in O(N!) time with heavy branch overhead. Bitmask backtracking achieves 15× to 25× speedups by eliminating all array indexing and executing entirely within CPU L1 registers. "
   "In propositional satisfiability (SAT), encoding N-Queens into Conjunctive Normal Form (CNF) allows industrial CDCL (Conflict-Driven Clause Learning) solvers to resolve instances with thousands of variables in seconds. "
   "CDCL surpasses classical DPLL (Davis-Putnam-Logemann-Loveland) by replacing chronological backtracking with 1UIP (First Unique Implication Point) conflict clause learning and non-chronological backjumping, "
   "while Two-Watched-Literals (2WL) indexing eliminates clause traversal overhead and provides instantaneous O(1) backtracking without pointer restoration. "
   "Finally, heuristic local search algorithms (such as Min-Conflicts) solve instances of N-Queens for N = 1,000,000 in seconds by iteratively repairing conflicts, demonstrating the profound interplay between exact complete search and heuristic incomplete optimization."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the state space pruning mechanics, bitmask register operations, and theoretical scaling of Backtracking and Boolean Satisfiability algorithms. "
   f"Through systematic benchmarking across board dimensions from N = {rows[0]['input']} to {rows[-1]['input']} queens, we verified the empirical bitwise operation slope "
   f"k_bit = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept T_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical elegance of Bitmask Backtracking, DPLL unit propagation, Two-Watched-Literals indexing, and CDCL conflict analysis, "
   "proving why constraint satisfaction and SAT solving form the computational bedrock of modern automated theorem proving, electronic design automation (EDA), compiler optimization, and artificial intelligence."
  )
 elif slug=='b-tree-disk-indexing':
  abstract=(
   f"Seven benchmark trials were generated across B+ Tree index heights / search depths h = {rows[0]['input']} to h = {rows[-1]['input']} levels "
   f"(total in-node binary search key comparisons C from {rows[0]['raw']} to {rows[-1]['raw']} comparisons). "
   f"An ordinary least-squares regression of key comparisons against tree height yielded an empirical scaling slope of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} comparisons, "
   f"demonstrating exact agreement with Rudolf Bayer's multi-way block indexing model C(h) = 8h (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by aligning high-fanout node pages (order m = 256) with 4096-byte disk blocks, "
   f"each index level evaluates in exactly log₂(256) = 8 scalar comparisons while requiring strictly h physical block I/O reads."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = h represents B+ Tree index traversal height in levels, "
   f"y = C represents total in-node binary search key comparisons, m represents the comparison slope k_node, and b represents "
   f"the baseline comparison offset (theoretically C_0 = 0.0000 comparisons). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of External Memory Algorithm theory and the Disk Access Machine (DAM) model. "
   "In secondary storage architectures, the astronomical latency gap between volatile DRAM (50–100 ns) and non-volatile flash SSDs (10–50 µs) or rotating HDDs (5–10 ms) "
   "renders traditional binary search trees (AVL or Red-Black trees) unviable: indexing 16 million records requires 24 binary levels, imposing 24 random disk seeks (up to 240 ms per query). "
   "The B-Tree, invented by Rudolf Bayer and Edward McCreight (1970), eliminates this bottleneck by matching node capacity to operating system disk block clusters (typically 4096 bytes). "
   "With an order of m = 256 child pointers and 255 keys per 4KB page, a B+ Tree indexes over 16.78 million records in a tree of height only h = 3 levels, "
   "reducing disk seeks from 24 down to 3 block reads—an 8× reduction in physical I/O overhead. "
   "Within each visited 4KB page in the buffer pool, contiguous sorted key alignment enables branch-free binary search across the 255 keys in exactly log₂(256) = 8 scalar comparisons. "
   "Across all benchmark trials from h = 2 to h = 8 levels, the empirical regression slope m = 8.0000 comparisons/level and intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "Comparative architectural analysis elucidates fundamental trade-offs across storage indexing paradigms: "
   "Binary Search Trees execute in O(log₂ N) time but suffer disastrous I/O fragmentation due to 32-byte node footprints. "
   "B+ Trees segregate routing index keys from leaf data records, maintaining a doubly-linked leaf chain that enables raw sequential disk throughput on range queries (SELECT ... BETWEEN). "
   "Hash Indexes achieve O(1) point lookups in memory but cannot execute range scans and suffer catastrophic performance degradation under external memory bucket overflows. "
   "Log-Structured Merge-Trees (LSM-Trees, used in RocksDB and Cassandra) optimize write-heavy workloads by buffering updates in memory (MemTable) and appending immutable SSTables to disk, "
   "trading read amplification (inspecting multiple levels) for sequential write throughput. "
   "Finally, transaction durability analysis emphasizes the vital role of Write-Ahead Logging (WAL) and the ARIES recovery protocol: "
   "buffering dirty B+ Tree pages in DRAM maximizes throughput, while sequential append-only WAL flushes ensure complete crash recovery with zero data loss."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the multi-way branching mechanics, block I/O alignment, and in-page binary search scaling of B-Trees and B+ Trees. "
   f"Through systematic benchmarking across tree depths from h = {rows[0]['input']} to {rows[-1]['input']} levels, we verified the empirical comparison slope "
   f"k_node = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept C_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical necessity of B+ Tree page alignment, high-fanout routing, and buffer pool caching, "
   "proving why B+ Trees remain the universal, irreplaceable storage engine backbone of relational database management systems, operating system file systems, and enterprise storage infrastructure."
  )
 elif slug=='fast-fourier-transform':
  abstract=(
   f"Seven benchmark trials were generated across power-of-two transform sizes N = {rows[0]['input']} to N = {rows[-1]['input']} points "
   f"(total radix-2 butterfly operations B from {rows[0]['raw']} to {rows[-1]['raw']} butterflies). "
   f"An ordinary least-squares regression of butterfly operations against the composite complexity coordinate x = N log₂(N) yielded an empirical multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} butterflies, "
   f"demonstrating exact agreement with Cooley and Tukey's decimation-in-time invariant B(N) = 0.5 N log₂(N) (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by recursively bisecting an N-point sequence into even and odd sub-transforms and combining them across log₂(N) stages, "
   f"each stage executes exactly N/2 dual-output butterfly arithmetic operations."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = N · log₂(N) represents the composite algorithmic complexity coordinate in work units, "
   f"y = B represents total radix-2 butterfly operations, m represents the butterfly scaling multiplier k_fft, and b represents "
   f"the baseline arithmetic offset (theoretically B_0 = 0.0000 butterflies). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Fourier Transform theory, discrete orthogonal projections, and divide-and-conquer asymptotic complexity. "
   "The Discrete Fourier Transform (DFT) converts a discrete complex time-domain sequence of length N into its orthogonal frequency-domain spectrum. "
   "Direct matrix-vector evaluation against the dense N×N Vandermonde Fourier matrix scales quadratically as Θ(N²), requiring N² complex multiplications and N(N-1) complex additions. "
   "For real-time audio processing, telecommunications (OFDM/5G), and scientific simulation, quadratic scaling is computationally prohibitive: an N = 65,536 sample buffer demands over 4.29 billion multiplications. "
   "In 1965, James W. Cooley and John W. Tukey published their Radix-2 Decimation-in-Time (DIT) algorithm, reducing complexity from Θ(N²) to strictly Θ(N log₂ N). "
   "For N = 65,536, Cooley-Tukey evaluates the transform using only ~524,000 operations—a computational acceleration exceeding 8,000×! "
   "The algorithm recursively partitions an N-point sequence into two (N/2)-point sequences (one containing even-indexed samples and the other odd-indexed samples). "
   "Exploiting the rotational periodicity (W_N^(k+N) = W_N^k) and half-period anti-symmetry (W_N^(k+N/2) = -W_N^k) of complex twiddle factors (W_N = exp(-2πi/N)), "
   "the sub-transform outputs are recombined across log₂(N) stages using dual-output 'butterfly' arithmetic kernels. "
   "Each butterfly executes 1 complex multiplication and 2 complex additions. "
   "Across the entire transform, each of the log₂(N) stages executes exactly N/2 butterflies, establishing the exact theoretical invariant B(N) = 0.5000 · N log₂(N) butterfly operations. "
   "Across all benchmark trials from N = 64 to N = 4096 points, the empirical regression slope m = 0.5000 butterflies/(N log₂ N) and intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "The investigation also verified the profound utility of the Bit-Reversal Permutation, which reorders the input array into recursive leaf order, allowing non-recursive bottom-up execution with O(1) auxiliary memory. "
   "Finally, application benchmarks demonstrated the power of the Convolution Theorem: cyclic convolution in the time domain corresponds to element-wise pointwise multiplication in the frequency domain. "
   "This reduces polynomial multiplication C(x) = A(x)B(x) from O(N²) in classical Cauchy multiplication down to strictly O(N log N) via forward FFT, pointwise product, and inverse FFT, "
   "forming the algorithmic foundation of modern cryptography, computer algebra systems, and large-integer arithmetic."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the decimation-in-time decomposition, butterfly network mechanics, and asymptotic scaling of the Cooley-Tukey Fast Fourier Transform. "
   f"Through systematic benchmarking across transform sizes from N = {rows[0]['input']} to {rows[-1]['input']} points, we verified the empirical butterfly multiplier "
   f"k_fft = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept B_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical indispensability of bit-reversal permutations, twiddle factor symmetries, and frequency-domain convolution, "
   "proving why the Fast Fourier Transform is universally recognized as one of the most critical algorithmic discoveries of the twentieth century."
  )
 elif slug=='a-star-pathfinding-heuristics':
  abstract=(
   f"Seven benchmark trials were generated across optimal grid path distances D = {rows[0]['input']} to D = {rows[-1]['input']} steps "
   f"(total closed set node expansions E from {rows[0]['raw']} to {rows[-1]['raw']} expansions). "
   f"An ordinary least-squares regression of closed set expansions against path distance yielded an empirical scaling factor of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} expansions, "
   f"demonstrating exact agreement with Hart, Nilsson, and Raphael's A* heuristic corridor invariant E(D) = 3D (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by coupling exact path-cost-to-come g(n) with an admissible and consistent Manhattan heuristic h(n), "
   f"A* prunes over 90% of the state space relative to blind Dijkstra search, expanding exactly 3 candidate vertices per unit path step."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = D represents the optimal path distance in grid steps, "
   f"y = E represents total closed set node expansions, m represents the heuristic expansion factor k_astar, and b represents "
   f"the baseline expansion offset (theoretically E_0 = 0.0000 expansions). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Informed State Space Search theory, heuristic admissibility, and the optimality of A*. "
   "In discrete graph pathfinding, blind uninformed search algorithms—such as Breadth-First Search (BFS) and Dijkstra's algorithm (h = 0)—explore vertices in radially symmetric concentric circles, "
   "expanding an area of πD² = Θ(D²) nodes across 2D planar maps. For large-scale geographical navigation or high-dimensional robotic motion planning, quadratic scaling becomes computationally intractable. "
   "In 1968, Peter Hart, Nils Nilsson, and Bertram Raphael introduced the A* Search Algorithm, evaluating states using f(n) = g(n) + h(n), combining exact cost-to-come g(n) with heuristic cost-to-go h(n). "
   "When the heuristic function h(n) satisfies admissibility (h(n) ≤ h*(n)) and consistency (h(u) ≤ c(u, v) + h(v)), A* is guaranteed to find an optimal shortest path without ever reopening closed vertices. "
   "In our 4-connected grid environment, the Manhattan heuristic h(n) = |x - x_goal| + |y - y_goal| creates an optimal potential gradient pointing directly toward the target. "
   "At each step along the path, A* extracts the minimum-f vertex from the binary min-heap Open Set, expands its orthogonal neighbors, and immediately advances along the direct line of sight. "
   "Across all benchmark trials from D = 10 to D = 70 grid steps, the empirical regression slope m = 3.0000 expansions/grid-step and baseline intercept b = 0.0000 confirm this linear corridor invariant with zero residual variance (R² = 1.00000). "
   "Comparative architectural analysis elucidates fundamental trade-offs across pathfinding paradigms: "
   "Dijkstra's algorithm guarantees optimality but suffers quadratic expansion overhead. Greedy Best-First search (f = h) rushes toward the goal but is sub-optimal and easily trapped in concavities and dead ends. "
   "A* strikes the mathematically optimal balance between path cost and search effort. "
   "Furthermore, modern extensions illustrate advanced performance scaling: Jump Point Search (JPS) exploits grid symmetries to jump directly between obstacle turning points, reducing Open Set operations by up to 95%, "
   "while Hierarchical Pathfinding (HPA*) and Lifelong Planning A* (LPA*) enable real-time dynamic replanning across massive video game worlds and autonomous robotics fleets."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the evaluation function mechanics, heuristic consistency invariants, and linear corridor scaling of the A* Search Algorithm. "
   f"Through systematic benchmarking across path distances from D = {rows[0]['input']} to {rows[-1]['input']} grid steps, we verified the empirical expansion factor "
   f"k_astar = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept E_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical elegance of admissible heuristic guidance, priority queue open sets, and state space pruning, "
   "proving why A* remains the premier, universally implemented pathfinding algorithm in robotics, video game development, artificial intelligence, and global navigation systems."
  )
 elif slug=='lru-cache-replacement':
  abstract=(
   f"Seven benchmark trials were generated across physical cache frame capacities C = {rows[0]['input']} to C = {rows[-1]['input']} frames "
   f"(total in-memory cache hits H from {rows[0]['raw']} to {rows[-1]['raw']} hits out of N = 200 memory references). "
   f"An ordinary least-squares regression of cache hits against frame capacity yielded an empirical marginal hit rate of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} hits, "
   f"demonstrating exact agreement with Denning's working set locality model H(C) = 6C (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by maintaining strict temporal recency via a Doubly-Linked Hash Map, "
   f"each additional physical frame captures an exact linear slice of recurring loop references, boosting hit ratios from 12.0% at C = 4 to 84.0% at C = 28."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = C represents cache frame capacity in frames, "
   f"y = H represents total in-memory cache hits, m represents the marginal hit rate k_lru, and b represents "
   f"the baseline hit offset (theoretically H_0 = 0.0000 hits). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Virtual Memory Architecture, Caching Theory, and Denning's Principle of Locality. "
   "In modern computer systems, the immense access latency gap between volatile DRAM (50–100 ns) and secondary NVMe SSD storage (10–50 µs) creates an astronomical performance penalty "
   "whenever a requested virtual page is not resident in physical memory. Evaluating Effective Memory Access Time (EMAT = h·t_hit + (1-h)·t_fault) demonstrates that even a 5% page fault rate "
   "degrades system performance by over 500%, explaining why optimizing page replacement policies is vital to operating system stability. "
   "The investigation evaluated the four foundational page replacement algorithms: "
   "Laszlo Belady's Optimal Algorithm (OPT / MIN, 1966) establishes the theoretical lower bound on page faults by evicting the page needed furthest in the future; "
   "however, because general-purpose operating systems cannot predict future memory references with clairvoyance, OPT serves solely as an offline gold standard. "
   "First-In, First-Out (FIFO) evicts the oldest resident frame; however, FIFO ignores access recency and is susceptible to Belady's Anomaly, where allocating more physical frames paradoxically increases page faults! "
   "Least Recently Used (LRU) exploits temporal locality by evicting the frame that has remained unreferenced for the longest time. "
   "Crucially, LRU belongs to the class of 'Stack Algorithms' satisfying Mattson's Inclusion Property (S(C) ⊆ S(C+1)), mathematically guaranteeing monotonic hit rate growth as cache capacity expands. "
   "In our software benchmark, LRU is implemented in strict O(1) time using a Hash Map paired with a Doubly-Linked List: hash lookup identifies target nodes in O(1) time, "
   "and 4 pointer updates splice nodes to the MRU head or evict the LRU tail. "
   "Across all benchmark trials from C = 4 to C = 28 frames, the empirical regression slope m = 6.0000 hits/frame and baseline intercept b = 0.0000 confirm the linear working set expansion model with zero residual variance (R² = 1.00000). "
   "Finally, operating system architectural analysis highlighted the Second-Chance Clock Algorithm: because tracking true LRU timestamps on every memory instruction introduces prohibitive hardware overhead, "
   "production kernels (Linux, FreeBSD, Windows NT) implement Clock approximation, sweeping a circular frame buffer with a single MMU-maintained hardware reference bit R to achieve near-LRU efficiency with zero runtime overhead."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the memory hierarchy dynamics, O(1) doubly-linked list mechanics, and working set scaling of the LRU Page Replacement Algorithm. "
   f"Through systematic benchmarking across frame capacities from C = {rows[0]['input']} to {rows[-1]['input']} frames, we verified the empirical marginal hit rate "
   f"k_lru = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept H_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical necessity of stack algorithms, temporal locality caching, and second-chance clock approximations, "
   "proving why LRU and its architectural descendants form the foundational core of modern virtual memory management, database buffer pools, and high-performance computing systems."
  )
 elif slug=='cryptographic-rsa-modular':
  abstract=(
   f"Seven benchmark trials were generated across private key exponent bit lengths B = {rows[0]['input']} to B = {rows[-1]['input']} bits "
   f"(total modular exponentiation operations M from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of modular operations against exponent bit length yielded an empirical multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} operations, "
   f"demonstrating exact agreement with Rivest, Shamir, and Adleman's Square-and-Multiply invariant M(B) = 1.5B (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by scanning the binary bitstring of the exponent, "
   f"modular exponentiation executes exactly B squarings and 0.5 B multiplications, reducing operational complexity from exponential O(2^B) to strictly linear O(B)."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = B represents exponent bit length in bits, "
   f"y = M represents total modular arithmetic operations (squarings and multiplications), m represents the exponentiation multiplier k_mod, and b represents "
   f"the baseline arithmetic offset (theoretically M_0 = 0.0000 operations). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Public-Key Asymmetric Cryptography, Modular Arithmetic, and the RSA Cryptosystem. "
   "Traditional symmetric key cryptography requires sharing identical secret keys in advance, creating an intractable O(N²) key distribution problem in global networks. "
   "In 1977, Ron Rivest, Adi Shamir, and Leonard Adleman solved this dilemma by inventing RSA, founded upon asymmetric one-way trapdoor permutations. "
   "Under RSA, encryption C = M^e mod n is publicly accessible, while decryption M = C^d mod n requires the private key exponent d = e^(-1) mod φ(n). "
   "According to Euler's Totient Theorem, if gcd(M, n) = 1, then M^φ(n) ≡ 1 mod n. Because e·d ≡ 1 mod φ(n), the exponents satisfy e·d = k·φ(n) + 1, "
   "guaranteeing that C^d ≡ (M^e)^d = M^(k·φ(n)+1) ≡ (1)^k · M ≡ M mod n. "
   "The Extended Euclidean Algorithm computes the modular inverse private key d in strictly logarithmic O(log(min(e, φ(n)))) steps by solving Bézout's identity e·d + φ(n)·y = 1. "
   "To evaluate modular powers with large cryptographic exponents without executing 10^616 operations, the Square-and-Multiply algorithm scans the binary bits of the exponent: "
   "every bit position unconditionally executes a modular squaring, and bits with value 1 execute an additional modular multiplication. "
   "Across all benchmark trials from B = 64 to B = 4096 bits, the empirical regression slope m = 1.5000 operations/bit and baseline intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "Comparative cryptographic security analysis evaluated the integer factorization hardness under the General Number Field Sieve (GNFS), "
   "demonstrating why 512-bit RSA is obsolete, 1024-bit is deprecated, 2048-bit represents the robust standard, and post-quantum lattice cryptography is emerging to counter quantum Shor's algorithm."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the asymmetric key synthesis mechanics, modular inverse derivation, and Square-and-Multiply scaling of the RSA Cryptosystem. "
   f"Through systematic benchmarking across exponent bit lengths from B = {rows[0]['input']} to {rows[-1]['input']} bits, we verified the empirical exponentiation multiplier "
   f"k_mod = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept M_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical necessity of one-way trapdoor functions, Euler's totient theorem, and constant-time modular arithmetic, "
   "proving why RSA and public-key cryptography remain the foundational pillar of Internet security, digital signatures, and global confidential communications."
  )
 elif slug=='concurrency-synchronization-deadlock':
  abstract=(
   f"Seven benchmark trials were generated across worker thread concurrency levels N = {rows[0]['input']} to N = {rows[-1]['input']} threads "
   f"(total atomic synchronization operations S from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of atomic operations against thread count yielded an empirical scaling multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} operations, "
   f"demonstrating exact agreement with Dijkstra's resource hierarchy synchronization model S(N) = 4N (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by breaking Coffman's circular wait condition through asymmetric lock ordering, "
   f"each thread completes its critical section in strictly 4 atomic operations without deadlocks or starvation."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = N represents worker thread count in threads, "
   f"y = S represents total atomic synchronization operations, m represents the step multiplier k_sync, and b represents "
   f"the baseline operation offset (theoretically S_0 = 0.0000 operations). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Concurrent Systems Theory, Synchronization Primitives, and Deadlock Dynamics. "
   "In multi-core computing architectures, non-deterministic thread interleavings create race conditions that corrupt shared mutable data unless protected by mutual exclusion. "
   "However, improper synchronization introduces a fatal failure mode: Deadlock. "
   "Edward G. Coffman Jr. proved in 1971 that deadlocks require four simultaneous conditions: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait. "
   "In Dijkstra's classic Dining Philosophers Problem, N threads compete for N shared mutex locks; under symmetric acquisition policies, simultaneous requests generate circular wait, causing all threads to permanently deadlock. "
   "Dijkstra eliminated this circular dependency through Resource Hierarchy: enforcing a global partial ordering on lock acquisitions guarantees that at least one thread acquires both resources and progresses. "
   "In our standardized concurrent execution model, each philosopher thread executes exactly 4 atomic synchronization operations per cycle: two lock acquires (left and right forks) and two lock releases. "
   "Across N threads, the cumulative atomic operation count scales strictly as S(N) = 4.0000 · N operations. "
   "Across all benchmark trials from N = 2 to N = 14 threads, the empirical regression slope m = 4.0000 operations/thread and baseline intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "Comparative analysis across concurrency paradigms highlights critical architectural trade-offs: "
   "Resource Allocation Graphs (RAG) detect deadlock cycles in O(|V| + |E|) time using Tarjan's strongly connected components. "
   "Dijkstra's Banker's Algorithm evaluates multi-instance resource matrices at runtime to guarantee safe state transitions. "
   "Finally, real-world operating system case studies—such as the 1997 Mars Pathfinder priority inversion incident—demonstrate the necessity of Priority Inheritance Protocols (PIP) "
   "to prevent low-priority threads from indefinitely stalling mission-critical high-priority tasks."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the atomic synchronization mechanics, resource hierarchy partial ordering, and deadlock prevention scaling of Concurrent Systems. "
   f"Through systematic benchmarking across thread counts from N = {rows[0]['input']} to {rows[-1]['input']} threads, we verified the empirical synchronization multiplier "
   f"k_sync = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept S_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical necessity of breaking Coffman conditions, tracking resource allocation graphs, and implementing priority inheritance, "
   "proving why robust synchronization forms the computational bedrock of multi-core operating systems, high-performance database engines, and fault-tolerant distributed systems."
  )
 elif slug=='relational-query-optimization':
  abstract=(
   f"Seven benchmark trials were generated across relation cardinalities N = {rows[0]['input']} to N = {rows[-1]['input']} tuples "
   f"(total in-memory Hash Join operations T from {rows[0]['raw']} to {rows[-1]['raw']} operations). "
   f"An ordinary least-squares regression of tuple operations against relation cardinality yielded an empirical execution scaling multiplier of "
   f"{fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and an intercept of {fmt(f['b'],c['resultDecimals'])} operations, "
   f"demonstrating exact agreement with the dual-phase in-memory hash join invariant T(N) = 2N (difference = {percent:.4f}%). "
   f"The empirical telemetry confirms that by partitioning the build relation into in-memory hash buckets and probing matching keys in linear time, "
   f"the hash join executes exactly N build insertions and N probe comparisons, reducing join complexity from quadratic O(N²) to strictly linear O(N)."
  )
  graph_choice=(
   f"The mathematical regression fits the linear model y = mx + b, where x = N represents relation cardinality in tuples, "
   f"y = T represents total in-memory hash join operations (build insertions plus probe comparisons), m represents the join multiplier k_join, and b represents "
   f"the baseline operation offset (theoretically T_0 = 0.0000 operations). The gradient has physical units {c['gradientUnit']}."
  )
  discussion=(
   "The empirical benchmark observations provide rigorous quantitative verification of Relational Query Optimization, Relational Algebra Transformations, and Physical Join Dynamics. "
   "In relational database management systems (RDBMS), declarative SQL queries specify what data to retrieve, leaving the physical execution plan entirely to the query optimizer. "
   "The optimizer employs relational algebra equivalence rules—principally Predicate Pushdown (σ_p(R ⋈ S) ≡ (σ_p(R)) ⋈ S) and Projection Pruning—to eliminate non-qualifying tuples "
   "and redundant columns before expensive join operators are invoked, reducing intermediate cardinality by orders of magnitude. "
   "When evaluating physical equi-join operators, the optimizer searches among distinct execution paradigms: "
   "Nested Loop Join executes quadratic O(|R|·|S|) comparisons and incurs catastrophic disk I/O unless the outer relation is microscopic; "
   "Block Nested Loop Join reduces I/O to B(R) + ⌈B(R)/(B-2)⌉ · B(S) by chunking buffer pool frames; "
   "Index Nested Loop Join exploits clustered B+ Tree secondary indexes to achieve O(|R| log |S|) lookup time; "
   "Sort-Merge Join sorts both relations in O(N log N) time and executes a linear two-pointer merge, preserving interesting sort orders for downstream GROUP BY or ORDER BY clauses; and "
   "In-Memory Hash Join partitions the build relation R into a hash table in N steps and streams the probe relation S in N steps, achieving optimal linear O(N) execution. "
   "Across all benchmark trials from N = 1000 to N = 7000 tuples, the empirical regression slope m = 2.0000 comparisons/tuple and baseline intercept b = 0.0000 confirm this invariant with zero residual variance (R² = 1.00000). "
   "Furthermore, physical index analysis established the Index Scan Tipping Point (typically 2% to 10% selectivity): "
   "when range query selectivity exceeds this threshold, the accumulated random I/O overhead of unclustered B+ Tree page lookups exceeds sequential disk streaming bandwidth, "
   "justifying the optimizer's deliberate choice to bypass the index in favor of a Full Table Scan. "
   "Finally, System R Dynamic Programming (Selinger's algorithm) demonstrates how bottom-up enumeration of left-deep join trees enables pipelined tuple streaming while pruning exponential search spaces."
  )
  conclusion=(
   "This laboratory investigation quantitatively verified the cost models, relational algebra transformations, and linear scaling mechanics of Relational Query Optimization and the In-Memory Hash Join Operator. "
   f"Through systematic benchmarking across relation cardinalities from N = {rows[0]['input']} to {rows[-1]['input']} tuples, we verified the empirical execution multiplier "
   f"k_join = {fmt(value*c['resultScale'],c['resultDecimals'])} {c['resultUnit']} and baseline intercept T_0 = {fmt(f['b'],c['resultDecimals'])} {c['interceptUnit']} with an ideal R² = 1.00000. "
   "The investigation established the microarchitectural efficiency and theoretical necessity of predicate pushdown, left-deep pipelined trees, index scan tipping points, and dual-phase hash partitioning, "
   "proving why cost-based query optimization forms the foundational intellectual core of modern database management systems and enterprise analytics engines."
  )
 else:
  abstract=f"Empirical benchmark trials were generated across input sizes for {c['title']}."
  graph_choice=f"Regression fits y = mx + b for {c['fitEquation']}."
  discussion=f"Empirical observations align with theoretical bound {fmt(reference*c['resultScale'],c['resultDecimals'])} {c['resultUnit']}."
  conclusion=f"Quantitative benchmarking verified complexity scaling for {c['title']}."
 return abstract, graph_choice, discussion, conclusion

def report(c,rows,f,out):
 slug=c['slug']
 csvpath=f"/computer-science/{slug}/sample-data.csv"
 csv_content=io.StringIO()
 writer=csv.writer(csv_content)
 writer.writerow(['experiment',c['shortInput'].replace(' ','_')+'_n','key_comparisons','x_metric','fitted_comparisons','residual'])
 for r in rows:
  fit_y=f['m']*r['x']+f['b']
  writer.writerow([slug,r['input'],r['raw'],f"{r['x']:.4f}",f"{fit_y:.4f}",f"{r['y']-fit_y:.4f}"])
 (out/f"computer-science/{slug}/sample-data.csv").write_text(csv_content.getvalue())

 value,se,reference=estimate(c,f)
 percent=abs(value-reference)/reference*100
 uncertainty=uncertainty_text(c)
 abstract,graph_choice,discussion,conclusion=report_narrative(c,rows,f,value,percent,reference)

 obs="".join(
  f"<tr><td>{i+1}</td><td>{r['input']}</td><td>{r['raw']}</td><td>{r['x']:.4f}</td><td>{r['y']:.4f}</td><td>{f['m']*r['x']+f['b']:.4f}</td><td>{r['y']-(f['m']*r['x']+f['b']):.4f}</td></tr>"
  for i,r in enumerate(rows)
 )

 return f'''<div class="section-top"><div><div class="eyebrow">WORKED EXAMPLE · BENCHMARK OBSERVATIONS</div><h2>A complete example laboratory report.</h2></div><button class="secondary" onclick="window.print()">Print / save as PDF</button></div><div class="report-notice"><strong>Simulated demonstration data.</strong><p>This report illustrates formal algorithmic benchmarking, operation counting arithmetic, and regression analysis. Replace its observations with your own benchmark telemetry when preparing a practical submission.</p></div><div class="report-person"><span>Student: __________________</span><span>Student ID: __________________</span><span>Course: __________________</span><span>Date: __________________</span><span>Partner: __________________</span><span>Instructor: __________________</span></div><article class="lab-report"><h3>1. Title and aim</h3><p><strong>{E(c['title'])}.</strong> {E(c['aim'])}</p><h3>2. Abstract</h3><p>{E(abstract)}</p><h3>3. Apparatus and fixed settings</h3><ul>{''.join('<li>'+E(a['name'])+': '+E(a['purpose'])+'</li>' for a in c['apparatus'])}{''.join('<li>'+E(s)+'</li>' for s in c['settings'])}</ul><h3>4. Theory and graph choice</h3><p>{E(c['intro'])}</p><div class="report-equation">{E(c['fitEquation'])}</div><p>{E(graph_choice)}</p><h3>5. Method</h3><ol>{''.join('<li>'+E(s['text'])+'</li>' for s in c['procedure'])}</ol><h3>6. Observations and calculation table</h3><p>All benchmark observations use strictly controlled memory buffers. Values are recorded deterministically from the algorithmic comparator register. Residuals are computed relative to the ordinary least-squares regression line.</p><div class="table-card"><table><caption>Table 1. Seven simulated algorithmic benchmarks; x and y represent computational state metrics.</caption><thead><tr><th>No.</th><th>{E(c['inputLabel'])} ({E(c['inputUnit'])})</th><th>{E(c['rawLabel'])} ({E(c['rawUnit'])})</th><th>{E(c['xAxis'])}</th><th>{E(c['yAxis'])}</th><th>Fitted y</th><th>Residual</th></tr></thead><tbody>{obs}</tbody></table></div><p><a href="{csvpath}" download>Download the sample observations (CSV) ↓</a></p><h3>7. Worked calculation for one observation</h3><div class="report-equation">{E(worked(c,rows[0]))}</div><h3>8. Graph, gradient and final calculation</h3><div class="chart-card">{graph(c,rows,f)}</div><p>Circular markers represent empirical benchmark observations. The solid line represents the ordinary least-squares asymptotic linear fit.</p><div class="report-equation">x̄ = {fmt(f['mx'])}; ȳ = {fmt(f['my'])}<br>Σ(x − x̄)² = {fmt(f['sxx'])}<br>Σ(x − x̄)(y − ȳ) = {fmt(f['sxy'])}<br>m = Σ(x − x̄)(y − ȳ) / Σ(x − x̄)² = {fmt(f['m'],8)}<br>b = ȳ − mx̄ = {fmt(f['b'],8)}<br>{E(formula(c,f))}</div><h3>9. Uncertainty and comparison</h3><p>Percentage difference = |estimate − theoretical value| / |theoretical value| × 100 = <strong>{percent:.4f}%</strong>.</p><p>For n = 7 benchmark observations, Σresidual² = {fmt(f['sse'])}; s² = Σresidual²/(n − 2). Gradient standard error = √[s²/Σ(x − x̄)²] = {fmt(f['slopeSE'])}. Intercept standard error = √[s²(1/n + x̄²/Σ(x − x̄)²)] = {fmt(f['interceptSE'])}.</p><p>Propagating the fit parameters yields a <strong>fit standard error of {fmt(se*c['resultScale'])} {E(c['resultUnit'])}</strong>, with an ideal coefficient of determination R² = {f['r2']:.6f}.</p><p>{E(uncertainty)}</p><h3>10. Result and discussion</h3><div class="report-equation">{E(c['target'])} = {fmt(value*c['resultScale'],c['resultDecimals'])} {E(c['resultUnit'])}<br>Theoretical reference value: {fmt(reference*c['resultScale'],c['resultDecimals'])} {E(c['resultUnit'])}</div><p>{E(discussion)}</p><h3>11. Precautions and limitations</h3><ul>{''.join('<li>'+E(p)+'</li>' for p in c['precautions'])}</ul><p>{E(c['limitations'])} {E(c['modelExtra'])}</p><h3>12. Conclusion</h3><p>{E(conclusion)}</p></article>'''

def lesson_schema(c,part,path,title,desc,base):
 graph=[{'@type':'BreadcrumbList','itemListElement':[{'@type':'ListItem','position':1,'name':'Open STEM Lab','item':base+'/'},{'@type':'ListItem','position':2,'name':'Computer Science Laboratory','item':base+'/subjects/computer-science/'},{'@type':'ListItem','position':3,'name':c['shortTitle'],'item':base+f'/computer-science/{c["slug"]}/'}]}]
 if part=='experiment':
  graph.append({'@type':['WebPage','LearningResource','TechArticle'],'name':title,'description':desc,'url':base+path,'learningResourceType':'Interactive computational simulation','educationalLevel':'Undergraduate','about':c['title'],'inLanguage':'en','isPartOf':{'@type':'WebSite','name':'Open STEM Lab','url':base+'/'}})
  if c.get('quiz'):
   graph.append({'@type':'Quiz','name':c['shortTitle']+' Concept Understanding','hasPart':[{'@type':'Question','name':q['question'],'suggestedAnswer':[{'@type':'Answer','text':opt} for opt in q['options']],'acceptedAnswer':{'@type':'Answer','text':q['options'][q['correct']]}} for q in c['quiz']]})
 elif part=='theory':
  graph.append({'@type':['WebPage','TechArticle','FAQPage'],'name':title,'description':desc,'url':base+path,'about':c['title'],'inLanguage':'en','isPartOf':{'@type':'WebSite','name':'Open STEM Lab','url':base+'/'},'mainEntity':[{'@type':'Question','name':t['question'],'acceptedAnswer':{'@type':'Answer','text':t['answer']}} for t in c['topics']]})
 else:
  graph.append({'@type':['WebPage','ScholarlyArticle','TechArticle'],'name':title,'description':desc,'url':base+path,'about':c['title'],'inLanguage':'en','isPartOf':{'@type':'WebSite','name':'Open STEM Lab','url':base+'/'}})
 return json.dumps({'@context':'https://schema.org','@graph':graph},ensure_ascii=False)

def shell(c,part,body,base,production):
 from build_catalog import head
 path=f'/computer-science/{c["slug"]}/'+('' if part=='experiment' else part+'/')
 title=c['shortTitle']+(' Experiment & Simulation' if part=='experiment' else ' Theory & Analysis' if part=='theory' else ' Lab Report: Benchmarks & Calculations')+' | Open STEM Lab'
 desc={'experiment':c['aim']+' Explore interactive search algorithms, compare operation counts and analyse complexity scaling.','theory':'Understand '+c['shortTitle'].lower()+': recurrence relations, Big-O bounds, decision trees and hardware cache interactions.','report':'A worked '+c['shortTitle'].lower()+' lab report with benchmark data tables, asymptotic graphs, calculations, uncertainty and conclusions.'}[part]
 header=head(path,title,desc,base,production).replace('<link rel="stylesheet" href="/catalog.css">','<link rel="stylesheet" href="/style.css"><link rel="stylesheet" href="/cs-lesson.css">')
 header=re.sub(r'<script type="application/ld\+json">.*?</script>',lambda _:f'<script type="application/ld+json">{lesson_schema(c,part,path,title,desc,base)}</script>',header,flags=re.S)
 home=f'/computer-science/{c["slug"]}/'
 nav='<aside class="sidebar"><a class="brand" style="font-size:20px" href="/">◉ openstemlab.</a><a class="side-subject" href="/subjects/computer-science/">← Computer Science labs</a><div class="side-label">LABORATORY '+str(c['number']).zfill(2)+'</div><nav aria-label="Lesson navigation">'
 for href,label in [(home,'Explore the experiment'),(home+'theory/','Understand the theory'),(home+'#apparatus','Know your tools'),(home+'#method','Follow the method'),(home+'#results','Analyse your results'),(home+'#check','Check your understanding'),(home+'report/','Sample lab report')]:
  nav+=f'<a class="nav-item{" active" if path==href else ""}" href="{href}">{label}</a>'
 nav+='<a class="nav-item" href="/experiments/">Search all experiments</a></nav><div class="side-note"><span class="small-sun">✳</span><p>Learn by computing.<br>Understand by benchmarking.</p></div><a class="text-button" href="/">← All subjects</a></aside>'
 heading=c['title'] if part=='experiment' else c['shortTitle']+' theory' if part=='theory' else c['shortTitle']+' lab report'
 return header+'<body>'+nav+'<main><header class="topbar"><div><a href="/subjects/computer-science/">Computer Science</a> / '+E(c['shortTitle'])+'</div><span class="free-label">FREE TO EXPLORE</span></header><section class="page-heading"><div class="eyebrow">LABORATORY '+str(c['number']).zfill(2)+' · COMPUTER SCIENCE</div><h1>'+E(heading)+'</h1><p>'+E(desc)+'</p></section><nav class="lab-navigation" aria-label="Experiment pages"><a href="'+home+'">Workbench</a><a href="'+home+'theory/">Detailed theory</a><a href="'+home+'#method">Method</a><a href="'+home+'#results">My results</a><a href="'+home+'report/">Example report</a></nav>'+body+'<footer><span class="footer-brand">openstemlab.</span><a href="/subjects/computer-science/">All computer science labs</a><span>Deterministic algorithmic model</span></footer></main>'+ ('<script id="labConfig" type="application/json">'+json.dumps(c,ensure_ascii=False).replace('<',chr(92)+'u003c')+'</script><script src="/cs-models.js"></script><script src="/cs-engine.js"></script>' if part=='experiment' else '')+'</body></html>'

def build_cs(out,base,production):
 published=[c for c in specs() if c['published']]
 for name,dest in [('models.js','cs-models.js'),('engine.js','cs-engine.js'),('lesson.css','cs-lesson.css')]:
  (out/dest).write_text((ROOT/'content/cs'/name).read_text())
 db=sqlite3.connect(ROOT/'data/catalog.sqlite3')
 sid=db.execute("SELECT id FROM subjects WHERE slug='computer-science'").fetchone()[0]
 db.execute("UPDATE subjects SET content_status='live' WHERE slug='computer-science'")
 paths=[]
 for c in published:
  slug=c['slug']
  home=f'/computer-science/{slug}/'
  (out/home.lstrip('/')).mkdir(parents=True,exist_ok=True)
  rows=[observation(c,v) for v in c['samples']]
  f=fit(rows)
  for part,body in [
   ('experiment',workbench(c)),
   ('theory','<section>'+theory(c)+f'<div class="insight"><span>↳</span><div><strong>Connect the theory to benchmark observations.</strong><p>{E(c["modelExtra"])}</p></div></div></section>'),
   ('report',report(c,rows,f,out))
  ]:
   path=home+('' if part=='experiment' else part+'/')
   file=out/path.lstrip('/')/'index.html'
   file.parent.mkdir(parents=True,exist_ok=True)
   file.write_text(shell(c,part,body,base,production))
   paths.append(path)
  db.execute('INSERT INTO experiments(subject_id,slug,title,status,page_path,theory_path,report_path) VALUES(?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET title=excluded.title,status=excluded.status,page_path=excluded.page_path,theory_path=excluded.theory_path,report_path=excluded.report_path',(sid,slug,c['shortTitle'],'live',home,home+'theory/',home+'report/'))
 db.commit()
 db.close()
 return paths

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser()
 parser.add_argument('--production',action='store_true')
 args=parser.parse_args()
 config=json.loads((ROOT/'site-config.json').read_text())
 base=config['base_url'].rstrip('/')
 out=ROOT/('release' if args.production else 'dist')
 out.mkdir(exist_ok=True)
 paths=build_cs(out,base,args.production)
 print(f"Built {len(paths)} CS pages for {base}: {paths}")
